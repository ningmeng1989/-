var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  // BASE_API: '"https://easy-mock.com/mock/5950a2419adc231f356a6636/vue-admin"',
   USER_BASE_API: '"http://10.200.64.3:8080/igauto/"', //开发
   // USER_BASE_API: '"http://api.igauto.test.intelligentgeely.com/igauto/"', //测试
  // BASE_API: '"http://10.200.179.177:8089/igauto/"' //杨汇贤
  // BASE_API: '"http://api.igauto.intelligentgeely.com/igauto/"', //生产
  // USER_BASE_API: '"http://api.igauto.test.intelligentgeely.com/igauto/"', //用户体系接口 base
  BASE_API: '"http://10.200.64.3:8084/dataview/"' //韩玉婷
  // BASE_API: '"http://api.igauto.test.intelligentgeely.com/igauto/"' //测试
  // BASE_API: '"http://10.200.125.213:9090/"' //柳友纯

})