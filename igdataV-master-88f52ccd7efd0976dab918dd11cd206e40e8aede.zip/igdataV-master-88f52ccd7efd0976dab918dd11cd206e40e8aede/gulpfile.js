/*!
 * @fileoverview
 *    gulp 的配置文件
 *
 * @author Dehua.Ke
 * @Email Dehua.Ke@geely.com
 * @Date 2017/4/26
 *
 * Copyright 2017 杭州的蓝科技 Inc. All Rights Reserved.
 */
var gulp = require('gulp');
var sftp = require('gulp-sftp');

/** ====================================== 项目属性配置区 ========================================== */
var SYSTEM_NAME = 'bops';
var STATIC_VERSION = 'v1.0.5';
// var RELEASE_VERSION = '201704';

var ROOT_PATH_DEV = ``;
var ROOT_PATH_VER = ``;
var ROOT_PATH_DEMO = ``;
var ROOT_PATH_RC = ``;
var ROOT_PATH_TEST = `/home/igcsc/view_igdata`;
var ROOT_PATH_PROD = ``;
// var ROOT_PATH_TEST = `/home/fe/web/*`;
// var ROOT_PATH_REL = `../static/${SYSTEM_SYMBOL}/${STATIC_VERSION}/`;
/** ====================================== 项目属性配置区 ========================================== */


/*
       测试环境：192.168.63.62，路径：/home/igcsc/view_igdata
       生产环境：192.168.12.177,路径：/home/ig_platform/view_igdata
*/


/**
 * 上传文件到开发服务器
 *
 * @returns
 */
gulp.task('ftp2dev', function () {

    return gulp.src('dist/**')
        .pipe(sftp({
            host: '10.200.180.23',
            user: 'dev',
            pass: '1qazcde3',
            timeout: 50000,
            remotePath: ROOT_PATH_DEV
        }));
});

/**
 * 上传文件到开发服务器 目录版本号
 *
 * @returns
 */
gulp.task('ftp2dev105', function () {

    return gulp.src('dist/**')
        .pipe(sftp({
            host: '10.200.180.23',
            user: 'dev',
            pass: '1qazcde3',
            timeout: 50000,
            remotePath: ROOT_PATH_VER
        }));
});

/**
 * 上传文件到 demo服务器
 *
 * @returns
 */
gulp.task('ftp2demo', function () {

    return gulp.src('dist/**')
        .pipe(sftp({
            host: '10.200.180.23',
            user: 'test',
            pass: '1qazcde3',
            timeout: 50000,
            remotePath: ROOT_PATH_DEMO
        }));
});

/**
 * 上传文件到内部测试服务器
 *
 * @returns
 */
gulp.task('ftp2pre', function () {

    return gulp.src('dist/**')
        .pipe(sftp({
            host: '10.200.180.23',
            user: 'rc',
            pass: '1qazcde3',
            timeout: 50000,
            remotePath: ROOT_PATH_RC
        }));
});

/**
 * 上传文件到质保测试 阿里环境
 * 需要VPN
 * @returns
 */
gulp.task('ftp2test', function () {

    return gulp.src('dist/**')
        .pipe(sftp({
            host: '192.168.63.62',
            user: 'igcsc',
            pass: 'igcsc',
            timeout: 50000,
            remotePath: ROOT_PATH_TEST
        }));
});

/**
 * 上传文件到线上生产 阿里环境
 * 需要VPN
 * @returns
 */
gulp.task('ftp2prod', function () {

    return gulp.src('dist/**')
        .pipe(sftp({
            host: '192.168.20.155',
            user: 'carfreeweb',
            pass: '1qazcde3!@#',
            timeout: 50000,
            remotePath: ROOT_PATH_PROD
        }));
});

gulp.task('default', function () {
    console.log("Hello");
});