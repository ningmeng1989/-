/*!
 * @fileoverview
 *    车型code 和车型图片之间的映射关系
 *  经过讨论，决定将车型code 和图片关系的维护放在前端实现
 *
 *
 * @author dehua.Ke
 * @Email dehua.Ke@geely.com
 * @Date 2018/6/11
 *
 * Copyright 2018 杭州的蓝科技 Inc. All Rights Reserved.
 */

let carTypeMap = {
    // CT00001	金刚
    // CT00010	远景X3

    // CT00014	全球鹰康迪K17A
    // CT00050	轻卡E200
    // CT00051	客车E12
    // CT00052	客车E10


    // CT00080	KC-2HB
    // CT00005	帝豪EV
    // CT00003	帝豪GL
    // CT00082	SX11P
    // CT00081	VF11P

    //帝豪EV
    "CT00005":"/static/img/powerData/dihao_ev.png",
    //帝豪PHEV
    "CT00006":"/static/img/powerData/dihao_ev.png",
    //金刚
    "CT00001":"/static/img/powerData/jingang.png",
    //远景X3
    "CT00010":"/static/img/powerData/yuanjingx3.png",
    //全球鹰康迪K17A
    "CT00014":"/static/img/powerData/K17.png",
    //轻卡E200
    "CT00050":"/static/img/powerData/E200.png",
    //客车E12
    "CT00051":"/static/img/powerData/E12.png",
    //客车E10
    "CT00052":"/static/img/powerData/E10.png",
    //KC-2HB
    "CT00080":"/static/img/powerData/kc_2hb.png",
    //帝豪GL
    "CT00003":"/static/img/powerData/dihao_GL.png",
    //VF11P
    "CT00081":"/static/img/powerData/vf11p.png",
    //SX11P
    "CT00082":"/static/img/powerData/SX11P.png",
    // //GE11
    // "CT00084":"/static/img/powerData/car_4.png",
    // //NL-5H
    // "CT00085":"/static/img/powerData/car_4.png",
    // //NL-P
    // "CT00086":"/static/img/powerData/car_4.png",
    // //NL-DA
    // "CT00087":"/static/img/powerData/car_4.png",
    // //PMA
    // "CT00088":"/static/img/powerData/car_4.png"
};


export default carTypeMap;