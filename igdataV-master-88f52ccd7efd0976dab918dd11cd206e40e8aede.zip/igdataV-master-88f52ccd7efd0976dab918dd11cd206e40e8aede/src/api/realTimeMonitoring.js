import fetch from '@/utils/fetch'
import Qs from 'qs' //URLSearchParams() 这玩意兼容极差现在改用qs

export function getQueryPlateOrVin(type, keyName) {
  // let queryParams = new URLSearchParams();
  // queryParams.append('type', type);
  // queryParams.append("keyName", keyName)
  let queryParams = Qs.stringify({ 'type': type, "keyName": keyName })

  return fetch({
    url: '/home/queryPlateOrVin',
    method: 'post',
    data: queryParams
  })
}

export function getQueryCarRealByVins(vin, userId) {
  // let queryParams = new URLSearchParams();
  // queryParams.append('vins', vin || "all");
  // queryParams.append("userId", userId)
  let queryParams = Qs.stringify({ 'vins': vin || "all", "userId": userId })

  return fetch({
    url: '/home/queryCarRealByVins',
    method: 'post',
    data: queryParams
  })
}

export function getQueryCarRealByPlateOrVin(type, keyName) {
  // let queryParams = new URLSearchParams();
  // queryParams.append('type', type);
  // queryParams.append("keyName", keyName)
  let queryParams = Qs.stringify({ 'type': type, "keyName": keyName })

  return fetch({
    url: '/home/queryCarRealByPlateOrVin',
    method: 'post',
    data: queryParams
  })
}

//数据分析
export function getStatisticsByBelonger(data) {
  // let queryParams = new URLSearchParams();
  // queryParams.append('userId', data.userId);
  let queryParams = Qs.stringify(data)

  return fetch({
    url: '/carInfo/querySyntheticalStatisticsByBelonger',
    method: 'post',
    data: queryParams
  })
}

//数据分析车辆统计
export function getStatisticByUserId(data) {
  // let queryParams = new URLSearchParams();
  // queryParams.append('userId', data.userId);
  let queryParams = Qs.stringify(data)

  return fetch({
    url: '/carInfo/queryCarStatusStatisticByUserId',
    method: 'post',
    data: queryParams
  })
}