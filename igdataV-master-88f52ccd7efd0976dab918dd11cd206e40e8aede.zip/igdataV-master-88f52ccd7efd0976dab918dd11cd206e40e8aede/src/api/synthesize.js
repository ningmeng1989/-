import fetch from '@/utils/fetch';
import Qs from 'qs';


/**
 *
 * 车辆总数
 *
 */
export function getVehicleCount() {
    return fetch({
        url: 'data/common/chart/vehicleCount',
        method: 'get'
    });
}

/**
 *
 * 车辆在线总数
 *
 */
export function getOnlineVehicleCount() {
    return fetch({
        url: 'data/common/chart/onlineVehicleCount',
        method: 'get'
    })
}

/**
 *
 * 行驶总时长查询
 *
 */
export function totalOnlineTime() {
    return fetch({
        url: 'data/common/chart/totalOnlineTime',
        method: 'get'
    });
}

/**
 *
 * 行驶总里程查询
 *
 */
export function totalTravelMileage() {
    return fetch({
        url: 'data/common/chart/totalTravelMileage',
        method: 'get'
    });
}

/**
 *
 * 机构车辆数TOP 6
 *
 */
export function getVehicleAscription(params) {
    return fetch.post('data/common/chart/vehicleAscription',params);
}

/**
 *
 * 机构车辆在线时长TOP 6
 *
 */
export function onlineTimeAscription(params) {
    return fetch.post('data/common/chart/onlineTimeAscription',params);
}



/**
 *
 * 报警信息查询接口
 *
 */
export function alertTypeByDate() {
    return fetch({
        url: 'data/common/chart/alertTypeByDate',
        method: 'get'
    })
}


/**
 *
 * 车辆类型占比信息TOP5查询接口
 *
 */
export function vehicleProportion() {
    return fetch({
        url: 'data/common/chart/vehicleProportion',
        method: 'get'
    })
}

/**
 *
 * 地图相关车辆位置统计查询接口
 *
 */
export function vehiclePolymerization(params) {
    return fetch({
        url: 'data/common/statistical/vehiclePolymerization',
        method: 'post',
        data: params
    })
}