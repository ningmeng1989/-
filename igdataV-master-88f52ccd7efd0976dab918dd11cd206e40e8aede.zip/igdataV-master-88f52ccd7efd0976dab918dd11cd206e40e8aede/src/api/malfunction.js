import fetch from '@/utils/fetch';
import Qs from 'qs';

/**
 * 平均故障数随里程变化情况
 *
 * @param params
 * @returns {*}
 *
 */
export function avgAlertByMileage(params) {
    return fetch.post(`/data/alert/avgAlertByMileage`,params);
}

/**
 * 获取具体车型电池信息
 *
 * @param params
 * @returns {*}
 *
 */
export function carTypes(params) {
    return fetch.post(`/carTypes/${params.code}`);
}


/**
 * 按里程获取车辆报警数比例
 *
 * @param params
 * @returns {*}
 *
 */
export function alertByMileage(params) {
    return fetch.post(`/data/alert/alertByMileage`,params);
}



/**
 * 获取指定时间段各省份平均报警topN
 *
 * @param params
 * @returns {*}
 *
 */
export function avgAlertByProvince(params) {
    return fetch.post(`/data/common/alert/avgAlertByProvince`,params);
}

/**
 * 按里程数获取报警类型数占比
 *
 * @param params
 * @returns {*}
 *
 */
export function alertTypeTop(params) {
    return fetch.post(`/data/common/alert/alertTypeTop`,params);
}



/**
 * 按里程数获取报警类型数TOPN
 *
 * @param params
 * @returns {*}
 *
 */
export function subsvstemAlertTypeTop(params) {
    return fetch.post(`/data/common/alert/subsvstemAlertTypeTop`,params);
}


/**
 * 获取指定时间段按月份统计的平均报警数
 *
 * @param params
 * @returns {*}
 *
 */
export function avgAlertByMonth(params) {
    return fetch.post(`/data/bar/alert/avgAlertByMonth`,params);
}

/**
 * 获取车型故障分析
 *
 * @param params
 * @returns {*}
 *
 */
export function statistics(params) {
    return fetch.post(`/data/alert/statistics`,params);
}









