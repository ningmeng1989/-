import fetch from '@/utils/fetch'
import Qs from 'qs' //URLSearchParams() 这玩意兼容极差现在改用qs


export function getQueryTrajectoryData(plate, startTime, endTime) {
  // let queryParams = new URLSearchParams();
  // queryParams.append('plate', plate);
  // queryParams.append('startTime', startTime);
  // queryParams.append('endTime', endTime)
  let queryParams = Qs.stringify({ 'plate': plate, 'startTime': startTime, 'endTime': endTime })

  return fetch({
    url: '/carReal/queryTrajectoryData', // 假地址 自行替换
    method: 'post',
    data: queryParams
  })
}