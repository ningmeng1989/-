import fetch from '@/utils/fetch';
import Qs from 'qs';


/**
 * 车型电池信息
 *
 * @param params
 * @returns {*}
 *
 */
export function getBattery(params) {
    return fetch.post(`/carTypes/${params.code}/battery`);
}


/**
 * 获取车型列表
 *
 * @param params
 * @returns {*}
 *
 */
export function getCarTypes() {
    return fetch.post(`/carTypes?all=false`);
}


/**
 * 获取指定时间段内每日充电频次接口
 *
 * @param params
 * @returns {*}
 *
 */
export function chargingByDay(params) {
    return fetch.post(`/data/bar/charging/chargingByDay`,params);
}

/**
 * 开始充电时刻分布数据接口
 *
 * @param params
 * @returns {*}
 *
 */
export function startChargingTime(params) {
    return fetch.post(`/data/bar/charging/startChargingTime`,params);
}



/**
 * 结束充电时刻分布数据接口
 *
 * @param params
 * @returns {*}
 *
 */
export function endChargingTime(params) {
    return fetch.post(`/data/bar/charging/endChargingTime`,params);
}




/**
 * 充电持续时间分布数据接口
 *
 * @param params
 * @returns {*}
 *
 */
export function chargingTime4Hour(params) {
    return fetch.post(`/data/bar/charging/chargingTime4Hour`,params);
}




/**
 * 结束充电剩余SOC分布数据接口
 *
 * @param params
 * @returns {*}
 *
 */
export function endSoc(params) {
    return fetch.post(`/data/bar/charging/endSoc`,params);
}

/**
 * 开始充电剩余SOC分布数据接口
 *
 * @param params
 * @returns {*}
 *
 */
export function startSoc(params) {
    return fetch.post(`/data/bar/charging/startSoc`,params);
}


/**
 * 24小时充电车辆数
 *
 * @param params
 * @returns {*}
 *
 */
export function chargingCount4time(params) {
    return fetch.post(`/data/line/charging/chargingCount4time`,params);
}


/**
 * 获取指定车型故障车辆列表
 *
 * @param params
 * @returns {*}
 *
 */
export function abnormityCars(params) {
    return fetch.post(`/data/abnormityCars`,params);
}










