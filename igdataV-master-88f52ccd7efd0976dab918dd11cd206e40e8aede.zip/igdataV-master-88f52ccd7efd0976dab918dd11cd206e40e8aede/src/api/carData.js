import fetch from '@/utils/fetch';
import Qs from 'qs';


/**
 * 搜索车辆
 *
 * @param params
 * @returns {*}
 *
 */
export function getCars(params) {
    return fetch.post('/cars', params);
}

/**
 *  获取车辆详情
 *
 * @param params
 * @returns {*}
 */
export function getCarInfoByVin(params) {
    return fetch.post(`/cars/${params.vin}`);
}

/**
 *  行程特点查询接口
 *
 * @param params
 * @returns {*}
 */
export function getTravelType(params) {
    return fetch.post(`/data/common/userAnalyze/getTravelType`,params);
}

/**
 *  常用充电位置查询
 *
 * @param params
 * @returns {*}
 */
export function getMostChargingAddr(params) {
    return fetch.post(`/data/common/charging/getMostChargingAddr`,params);
}

/**
 *  常用充电位置查询
 *
 * @param params
 * @returns {*}
 */
export function dayNightStopTimeMax(params) {
    return fetch.post(`/data/common/singleVehicle/dayNightStopTimeMax`,params);
}

/**
 *  行程半径查询
 *
 * @param params
 * @returns {*}
 */
export function getTravelRad(params) {
    return fetch.post(`/data/common/userAnalyze/getTravelRad`,params);
}

/**
 *  单车在线时长查询接口
 *
 * @param params
 * @returns {*}
 */
export function onlineSeconds(params) {
    return fetch.post(`/data/common/singleVehicle/onlineSeconds`,params);
}

/**
 *   单车报警数量查询接口
 *
 * @param params
 * @returns {*}
 */
export function alarmCount(params) {
    return fetch.post(`/data/common/singleVehicle/alarmCount`,params);
}

/**
 *   单车能耗查询接口
 *
 * @param params
 * @returns {*}
 */
export function energyConsumption(params) {
    return fetch.post(`/data/common/singleVehicle/energyConsumption`,params);
}

/**
 *   单车行驶里程查询接口
 *
 * @param params
 * @returns {*}
 */
export function travelMileage(params) {
    return fetch.post(`/data/common/singleVehicle/travelMileage`,params);
}

/**
 *   车辆行驶总时长、总里程、总油耗、最大速度复合查询接口
 *
 * @param params
 * @returns {*}
 */
export function getTravelQuery(params) {
    return fetch.post(`/data/common/userAnalyze/getTravelQuery`,params);
}

/**
 *
 *   对应车辆在近x千公里是否能耗异常
 *
 * @param params
 * @returns {*}
 */
export function energyAbnormity(params) {
    return fetch.post(`/data/car/energyAbnormity`,params);
}

/**
 *
 *    停车位置topN查询接口
 *
 * @param params
 * @returns {*}
 */
export function topNStopTime(params) {
    return fetch.post(`/data/common/singleVehicle/topNStopTime`,params);
}

