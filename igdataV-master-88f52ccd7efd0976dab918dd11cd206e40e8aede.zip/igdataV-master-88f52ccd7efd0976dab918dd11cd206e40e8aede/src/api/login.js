import loginAxios from '@/utils/loginAxios';
import Qs from 'qs';

export function login(account, password) {
  let data = Qs.stringify({ 'account': account, 'password': password })
  return loginAxios({
    url: '/system/login',
    method: 'post',
    data: data
  })
}

export function getInfo(token) {
  let data = Qs.stringify({ 'userId': token })
  return loginAxios({
    url: '/system/getUserPrivilegeModular',
    method: 'post',
    data: data
  })
}

export function logout(userId) {
  let data = Qs.stringify({ 'userId': userId })
  return loginAxios({
    url: '/system/exit',
    method: 'post',
    data: data
  })
}