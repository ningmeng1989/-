<template>
  <div class="amap-page-container" style="font-size:12px;">
    <!-- 地图 -->
    <el-amap ref="map" vid="amapDemo" :zoom="zoom" class="amap-demo" :events="events" :class="{hideSidebar:!sidebar.opened}">
      <el-amap-info-window :position="window.position" v-if="window.visible">
        <div class="infoWindowStyle">
          <div class="infoWindowStyle-title">更新时间:{{updateTime}}</div>
          <div class="infoWindowStyle-body">
            <el-row type="flex" class="row-bg" justify="space-around">
              <el-col :span="18">
                <div class="infoWindowStyle-info">
                  <p>车牌:{{plate}}</p>
                  <p>车型:{{type}} {{carSeatNum}}座</p>
                  <p>总里程:{{totalMileage}}</p>
                  <p>剩余电量:{{soc}}</p>
                  <p>地址:{{address}}</p>
                </div>
              </el-col>
              <el-col :span="6" style="height:77px;border-left:1px dashed #e9e9e9;margin:30px 0;">
                <div class="infoWindowStyle-speed" style="text-align: center">
                  <p style="font-size:40px">{{speed}}</p>
                  <p>Km/h</p>
                  <p>{{vehicleState}}</p>
                </div>
              </el-col>
            </el-row>
          </div>
          <div class="infoWindowStyle-buttom">
            <el-button type="primary" size="mini" @click.native="vehicleDetails">车辆详情</el-button>
            <el-button type="primary" size="mini" @click.native="vehicleCondition">实时车况</el-button>
            <el-button type="primary" size="mini" @click.native="TrajectoryTracking">轨迹追踪</el-button>
            <el-button type="primary" size="mini" @click.native="AlarmProcessing">报警处理</el-button>
          </div>
        </div>
      </el-amap-info-window>
    </el-amap>

    <!-- 地图放大缩小控件 -->
    <div class="map-zoom">
      <div class="map-zoom-plus" @click="add">
        <img src="static/img/plus.png" alt="">
      </div>
      <div class="map-zoom-minus" @click="minus">
        <img src="static/img/minus.png" alt="">
      </div>
    </div>

    <!-- 车辆状态选择条 -->
    <div class="status-tab">
      <el-tabs @tab-click="handleClick" v-model="activeName">
        <el-tab-pane name="1">
          <span slot="label" class="tab-item">
            <img class="img-1" src="static/img/all.png" alt="">
            <span class="tabs-item-title">全部</span>
          </span>
        </el-tab-pane>
        <el-tab-pane name="2">
          <span slot="label">
            <img class="img-2" src="static/img/yundong.png" alt="">
            <span class="tabs-item-title">运动</span>
          </span>
        </el-tab-pane>
        <el-tab-pane name="3">
          <span slot="label">
            <img class="img-3" src="static/img/xihuo.png" alt="">
            <span class="tabs-item-title">停止</span>
          </span>
        </el-tab-pane>
        <el-tab-pane name="4">
          <span slot="label">
            <img class="img-4" src="static/img/guzhang.png" alt="">
            <span class="tabs-item-title">故障</span>
          </span>
        </el-tab-pane>
        <el-tab-pane name="5">
          <span slot="label">
            <img class="img-5" src="static/img/chongdian.png" alt="">
            <span class="tabs-item-title">充电</span>
          </span>
        </el-tab-pane>
      </el-tabs>
      <el-dropdown class="dropdown" trigger="click" @command="handleCommand">
        <span class="el-dropdown-link">
          <i class="el-icon-arrow-down el-icon--right"></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="5">
            <img style="width:18px" src="static/img/yichang.png" alt=""> 异常
          </el-dropdown-item>
          <el-dropdown-item command="6">
            <img style="width:18px" src="static/img/ChargeTravel.png" alt=""> 运动充电
          </el-dropdown-item>
          <el-dropdown-item command="7">
            <img style="width:18px" src="static/img/ChargeFlameout.png" alt=""> 停止充电
          </el-dropdown-item>
          <el-dropdown-item command="8">
            <img style="width:18px" src="static/img/FaultTravel.png" alt=""> 运动故障
          </el-dropdown-item>
          <el-dropdown-item command="9">
            <img style="width:18px" src="static/img/FaultFlameout.png" alt=""> 停止故障
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>

    <!-- 搜索框 -->
    <div class="search">
      <el-autocomplete placeholder="请输入内容" class="input-with-select" :fetch-suggestions="querySearchAsync" @select="handleSelect" :value="searchValue">
        <el-select v-model="searchType" slot="prepend" placeholder="请选择">
          <el-option label="按车牌" value="0"></el-option>
          <el-option label="按VIN码" value="1"></el-option>
        </el-select>
        <el-button slot="append" icon="el-icon-search" @click.native="search" type="primary"></el-button>
      </el-autocomplete>
    </div>

    <!-- 车辆详情信息框 -->
    <el-dialog :visible.sync="dialogTableVisible">
      <car-msg :carDetailData="carBaseMsg"></car-msg>
    </el-dialog>
  </div>
</template>

<script>
  import { mapGetters, mapState } from "vuex";
  import {
    getQueryPlateOrVin,
    getQueryCarRealByPlateOrVin
  } from "@/api/realTimeMonitoring";
  import { getCarDetail } from "@/api/carCenter";
  import CarMsg from "@/components/carCenter/carMsg.vue";
  export default {
    computed: {
      ...mapGetters([
        "arrAll", // 7
        "arrAbnormal", //2
        "arrFlameout", // 0
        "arrChargeFlameout", //3
        "arrChargeTravel", // 4
        "arrTravel", //1
        "arrFaultTravel", //5
        "arrFaultFlameout", //6
        "sidebar"
      ])
    },
    components: { CarMsg },
    data() {
      let self = this;
      return {
        activeName: "1",
        searchValue: "",
        searchType: "",
        zoom: 5,
        window: {
          position: [0, 0],
          visible: false
        },
        map: "", //地图对象
        cluster: "", //地图聚合对象
        address: "", //转化的物理地址
        plate: "", //车牌
        soc: "", //电量
        type: "", //车型
        speed: "", //速度
        vehicleState: "", //车辆状态
        totalMileage: "", //总里程
        carSeatNum: "", //座位数
        updateTime: "", //更新时间
        timer: "", //计时器
        dialogTableVisible: false,
        carBaseMsg: "", //dialog数据
        arr: [],
        nIndex: "0", //用来存放序列
        events: {
          init(o) {
            // clearInterval(self.timer);
            self.map = self.$refs.map.$$getInstance();

            // self.timer = setTimeout(() => {
            //   let markers = self.getCarInfo(self.arrAll);
            //   self.cluster = new AMap.MarkerClusterer(o, markers, {
            //     gridSize: 60,
            //     maxZoom: 11,
            //     renderCluserMarker: self._renderCluserMarker
            //   });
            // }, 3500);
          }
        }
      };
    },
    // created() {
    //   //缩放到区的级别才开始轮询
    //   let _this = this;
    //   setTimeout(() => {
    //     let oMap = _this.map;
    //     oMap.on("zoomchange", function(e) {
    //       let zoom = oMap.getZoom();
    //       if (zoom > 13) {
    //         _this.handleClick({ index: _this.nIndex });
    //       } else {
    //         clearInterval(_this.timer);
    //       }
    //     });
    //   }, 1000);
    // },
    watch: {
      arrAll: function() {
        if (this.nIndex == "0" && !this.cluster) {
          let markers = this.getCarInfo(this.arrAll);
          this.cluster = new AMap.MarkerClusterer(this.map, markers, {
            gridSize: 60,
            maxZoom: 11,
            renderCluserMarker: this._renderCluserMarker
          });
        }
      }
    },
    activated() {
      if (this.window.visible) {
        this.window = {
          position: this.loglat,
          visible: true
        }
      }
      let _this = this;
      setTimeout(() => {
        let oMap = _this.map;
        oMap.on("zoomchange", function(e) {
          let zoom = oMap.getZoom();
          if (zoom > 13) {
            _this.handleClick({ index: _this.nIndex });
          } else {
            clearInterval(_this.timer);
          }
        });
      }, 1000);
    },
    mounted() {
      // let markers = [];
      // this.t = setInterval(() => {
      //   markers = this.getCarInfo(this.arrAll);
      //   this.cluster.setMarkers(markers);
      // }, 30000);
    },
    methods: {
      _renderCluserMarker(context) {
        let div = document.createElement("div");
        let cDiv = document.createElement("div");

        //设置父容器样式
        div.style.width = "48px";
        div.style.height = "48px";
        div.style.backgroundImage = "url(static/img/juhe.png)";
        div.style.fontSize = "12px";
        div.style.color = "#fff";
        div.style.position = "relative";

        //设置子容器样式
        cDiv.style.cssText = "-webkit-border-radius:50%";
        cDiv.style.border = "1px solid #fff";
        cDiv.style.width = "32px";
        cDiv.style.height = "32px";
        cDiv.style.textAlign = "center";
        cDiv.style.lineHeight = "32px";
        cDiv.style.background = "#1890FF";
        cDiv.style.position = "absolute";
        cDiv.style.right = "-8px";
        cDiv.style.top = "-10px";

        cDiv.innerHTML = context.count;
        div.appendChild(cDiv);
        context.marker.setContent(div);
        context.marker.setOffset(new AMap.Pixel(-24, -24));
      },
      handleCommand(command) {
        this.handleClick({ index: command });
        this.activeName = null;
      },
      handleClick(tab, event) {
        let markers = [];
        this.nIndex = tab.index;
        this.cluster.clearMarkers();
        this.map.clearMap();
        clearInterval(this.timer);
        // clearInterval(this.t);

        /*
                      需要优化：
                      30s 轮询有待优化 不知道什么原因state数据更新地图上显示的数据不会跟着变化

                      现在的做法是数据的轮询和显示的轮询是分开的：

                        数据每30s请求
                        一旦我点击了某个信息这个信息会有自己的30s轮询

                      */
        switch (tab.index) {
          case "0": // 全部
            markers = this.getCarInfo(this.arrAll);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrAll);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "1": //行驶
            markers = this.getCarInfo(this.arrTravel);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrTravel);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "2": //熄火
            markers = this.getCarInfo(this.arrFlameout);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrFlameout);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "7": //充电熄火
            markers = this.getCarInfo(this.arrChargeFlameout);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrChargeFlameout);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "6": //充电行驶
            markers = this.getCarInfo(this.arrChargeTravel);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrChargeTravel);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "5": //异常
            markers = this.getCarInfo(this.arrAbnormal);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrAbnormal);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "4": //充电
            markers = this.getCarInfo(
              this.arrChargeTravel.concat(this.arrChargeFlameout)
            );
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(
                  this.arrChargeTravel.concat(this.arrChargeFlameout)
                );
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "3": //故障
            markers = this.getCarInfo(
              this.arrFaultTravel.concat(this.arrFaultFlameout)
            );
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(
                  this.arrFaultTravel.concat(this.arrFaultFlameout)
                );
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "9": //故障熄火
            markers = this.getCarInfo(this.arrFaultFlameout);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrFaultFlameout);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;

          case "8": //故障行驶
            markers = this.getCarInfo(this.arrFaultTravel);
            this.cluster.setMarkers(markers);

            if (this.map.getZoom() > 13) {
              this.timer = setInterval(() => {
                markers = this.getCarInfo(this.arrFaultTravel);
                this.cluster.setMarkers(markers);
              }, 30000);
            }
            break;
        }
      },
      querySearchAsync(queryString, callback) {
        this.searchValue = queryString;
        let result = [];
        getQueryPlateOrVin(this.searchType, queryString).then(res => {
          let data = res.results;
          for (let i = 0, len = data.length; i < len; i++) {
            result.push({ value: data[i] });
          }
        });
        callback(result);
      },
      handleSelect(item) {
        this.searchValue = item.value;
      },
      search() {
        let result = [];
        // clearInterval(this.t);
        clearInterval(this.timer);
        getQueryCarRealByPlateOrVin(this.searchType, this.searchValue).then(
          res => {
            let data = res.results;
            let arrResult = [];
            for (let i = 0, len = data.length; i < len; i++) {
              arrResult.push({
                lnglat: [
                  data[i].carRealDataVo.longitude,
                  data[i].carRealDataVo.latitude
                ],
                vin: data[i].vin,
                plate: data[i].carBase.plate,
                type: data[i].carType.carTypeName,
                soc: data[i].carRealDataVo.soc,
                speed: data[i].carRealDataVo.speed,
                vehicleState: this.distinguishStatus(data[i]),
                totalMileage: data[i].carRealDataVo.totalMileage,
                carSeatNum: data[i].carType.carSeatNum,
                updateTime: data[i].carBase.updateTime
              });
            }
            let markers = this.getCarInfo(arrResult);
            this.cluster.setMarkers(markers);
            this.searchValue = "";
          }
        );
      },
      distinguishStatus(data) {
        if (data.carStatus.travelStatus == 2) {

          return 2
          //是否为故障
        } else if (data.carStatus.isBadStatus == 1) {
          if (data.carStatus.travelStatus == 1) {

            return 6

          } else if (data.carStatus.travelStatus == 0) {

            return 5
          }
          //是否为充电
        } else if (data.carStatus.chargingStatus == 1) {
          if (data.carStatus.travelStatus == 1) {

            return 3
          } else if (data.carStatus.travelStatus == 0) {

            return 4

          }
        } else if (
          data.carStatus.chargingStatus == 0 &&
          data.carStatus.isBadStatus == 0
        ) {
          if (data.carStatus.travelStatus == 1) {

            return 0
          } else if (data.carStatus.travelStatus == 0) {

            return 1

          }
        }
      },
      vehicleDetails() {
        // this.$router.push({ name: "车辆档案" });
        console.log(this.vin);
        let vin = { vin: this.vin };
        getCarDetail(vin).then(response => {
          this.dialogTableVisible = true;
          this.carBaseMsg = response.results;
        });
      },
      vehicleCondition() {
        this.$router.push({
          name: "单车监控"
        });
        this.$store.dispatch("getCarVin", this.vin);
      },
      TrajectoryTracking() {
        this.$router.push({ name: "轨迹查询", params: { plate: this.plate, lng: this.loglat } });
      },
      AlarmProcessing() {
        this.$router.push({ name: "实时报警", query: { vinId: this.vin } });
      },
      minus() {
        let mapObj = this.map;
        let zoom = mapObj.getZoom();
        let zoomIndexMinus = zoom - 1;
        if (zoomIndexMinus >= 3 && zoomIndexMinus <= 18) {
          mapObj.setZoom(zoomIndexMinus);
        }
      },
      add() {
        let mapObj = this.map;
        let zoom = mapObj.getZoom();
        let zoomIndexPlus = zoom + 1;
        if (zoomIndexPlus >= 3 && zoomIndexPlus <= 18) {
          mapObj.setZoom(zoomIndexPlus);
        }
      },
      getCarInfo(arr) {
        let markers = [],
          marker,
          content;
        for (var i = 0, len = arr.length; i < len; i += 1) {
          // 存下i 的值
          let ii = i;
          switch (arr[i]["vehicleState"]) {
            case 0:
              self.vehicleState = "熄火";
              content = `
              <div style="height:0px">
                <div style="position: absolute;top:0px;background:#FFAB0F;border-radius:18px;font-size: 12px;color: #FFFFFF;min-width: 70px;line-height:20px;text-align: center;">${arr[i]["plate"]}</div>
                <div style="position: relative;top:-45px;width:34px;height:34px;background:#FFF;border-radius:50%;margin:0 auto;">
                  <img style="position: absolute;top:6px;left:5px;" src="static/img/xihuo.png" alt="">
                </div>
              </div>
                      `;
              break;
            case 1:
              self.vehicleState = "行驶";
              content = `
                <div style="height:0px">
                  <div style="position:absolute;top:0px;background:#47A4FF;border-radius: 18px;font-size: 12px;color: #FFFFFF;min-width: 70px;line-height:20px;text-align: center;">${arr[i]["plate"]}</div>
                  <div style="position: relative;top:-45px;width:34px;height:34px;background:#FFF;border-radius:50%;margin:0 auto;">
                    <img style="position: absolute;top:6px;left:5px;" src="static/img/yundong.png" alt="">
                  </div>
                </div>
                      `;
              break;
            case 2:
              self.vehicleState = "异常";
              content = `
                <div style="height:0px;">
                  <div style="position:absolute;top:0px;background:#FF4646;border-radius: 18px;font-size: 12px;color: #FFFFFF;min-width: 70px;line-height:20px;text-align: center;">${arr[i]["plate"]}</div>
                  <div style="position: relative;top: -45px;width:34px;height:34px;background:#FFF;border-radius:50%;margin:0 auto;">
                    <img style="position:absolute;top:6px;left:5px;" src="static/img/yichang.png" alt="">
                  </div>
                </div>
                      `;
              break;
            case 3:
              self.vehicleState = "充电熄火";
              content = `
                <div style="height:0px;">
                  <div style="position:absolute;top:0px;background:#FFAB0F;border-radius: 18px;font-size: 12px;color: #FFFFFF;min-width: 70px;line-height:20px;text-align: center;">${arr[i]["plate"]}</div>
                  <div style="position: relative;top: -45px;width:34px;height:34px;background:#FFF;border-radius:50%;margin:0 auto;">
                    <img style="position:absolute;top:6px;left:5px;" src="static/img/ChargeFlameout.png" alt="">
                  </div>  
                </div>
                      `;
              break;
            case 4:
              self.vehicleState = "充电行驶";
              content = `
              <div style="height:0px;">
                <div style="position:absolute;top:0px;background:#47A4FF;border-radius: 18px;font-size: 12px;color: #FFFFFF;min-width: 70px;line-height:20px;text-align: center;">${arr[i]["plate"]}</div>
                <div style="position: relative;top: -45px;width:34px;height:34px;background:#FFF;border-radius:50%;margin:0 auto;">
                  <img style="position:absolute;top:6px;left:5px;" src="static/img/ChargeTravel.png" alt="">
                </div>  
              </div>
                      `;
              break;
            case 5:
              self.vehicleState = "故障行驶";
              content = `
                <div style="height:0px;">
                  <div style="position:absolute;top:0px;background:#47A4FF;border-radius: 18px;font-size: 12px;color: #FFFFFF;min-width: 70px;line-height:20px;text-align: center;">${arr[i]["plate"]}</div>
                  <div style="position: relative;top: -45px;width:34px;height:34px;background:#FFF;border-radius:50%;margin:0 auto;">
                    <img style="position:absolute;top:6px;left:5px;" src="static/img/FaultTravel.png" alt="">
                  </div>  
                </div>
                      `;
              break;
            case 6:
              self.vehicleState = "故障熄火";
              content = `
                <div style="height:0px;">
                  <div style="position:absolute;top:0px;background:#FFAB0F;border-radius: 18px;font-size: 12px;color: #FFFFFF;min-width: 70px;line-height:20px;text-align: center;">${arr[i]["plate"]}</div>
                  <div style="position: relative;top: -45px;width:34px;height:34px;background:#FFF;border-radius:50%;margin:0 auto;">
                    <img style="position:absolute;top:6px;left:5px;" src="static/img/FaultFlameout.png" alt="">
                  </div>
                </div>
                      `;
              break;
          }
          marker = new AMap.Marker({
            position: arr[i]["lnglat"],
            content: content,
            offset: new AMap.Pixel(-35, -38)
          });
          marker.on("click", event => {
            this.loglat = arr[ii]["lnglat"]; //经纬度
            this.vin = arr[ii]["vin"]; //vin
            this.plate = arr[ii]["plate"]; //车牌
            this.soc =
              arr[ii]["soc"] > 100 || arr[ii]["soc"] < 0 ?
              "--" :
              arr[ii]["soc"] + "%"; //电量
            this.type = arr[ii]["type"]; //车型
            this.speed =
              arr[ii]["speed"] == 65535 || arr[ii]["speed"] == 65534 ?
              "--" :
              arr[ii]["speed"]; //速度
            this.totalMileage =
              arr[ii]["totalMileage"] < 0 ? "--" : arr[ii]["totalMileage"] + "KM"; //总里程
            this.carSeatNum = arr[ii]["carSeatNum"]; // 座位数
            this.updateTime = arr[ii]["updateTime"]; //更新时间
            //转换为物理地址
            let self = this;
            this.geocoder.getAddress([self.loglat[0], self.loglat[1]], function(
              status,
              result
            ) {
              self.address = result.regeocode.formattedAddress;
            });
            //控制显示infowindow的显示隐藏
            this.window.visible = false;
            this.$nextTick(() => {
              //[event.lnglat.lng, event.lnglat.lat]
              this.window.position = this.loglat;
              this.window.visible = true;
            });
          });
          markers.push(marker);
        }
        return markers;
      }
    }
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .amap-demo {
    position: absolute;
    transition: 0.3s ease;
    width: calc(100% - 200px);
    height: calc(100% - 104px);
    &.hideSidebar {
      transition: 0.3s ease;
      width: calc(100% - 40px);
    }
    .infoWindowStyle {
      width: 426px;
      font-size: 14px;
      color: #000;
      margin: -10px -18px -10px -10px;
      &-title {
        border-bottom: 1px solid #e9e9e9;
        padding: 12px 24px;
      }
      &-body {
        width: 378px;
        border-bottom: 1px solid #e9e9e9;
        margin: 0 auto;
        opacity: 0.65;
      }
      &-img,
      &-speed,
      &-info {
        p {
          margin: 5px 0;
        }
      }
      &-buttom {
        padding: 12px 30px;
      }
    }
  }

  .map-zoom {
    position: absolute;
    right: 20px;
    bottom: 136px;
    border-radius: 2px;
    background: #fff;
    &::after {
      content: "";
      position: absolute;
      left: 12px;
      top: 41px;
      width: 14px;
      height: 2px;
      background: rgba(228, 231, 237, 0.6);
    }
    &-plus,
    &-minus {
      padding: 12px;
    }
  }

  .status-tab {
    position: absolute;
    top: 128px;
    right: 20px;
    width: 330px;
    height: 60px;
    background: #fff;
    padding: 6px 10px 0 10px;
    .dropdown {
      position: absolute;
      top: 38%;
      right: 10px;
    }
    .tabs-item-title {
      display: block;
      padding-top: 15px;
      font-size: 12px;
    }
    .img-1,
    .img-2,
    .img-3,
    .img-4,
    .img-5 {
      position: absolute;
    } // .img-1 {
    //   left: 6px;
    // }
    // .img-2,
    // .img-3,
    // .img-4 {
    //   right: 28px;
    // }
    // .img-5 {
    //   right: 8px;
    // }
  }

  .search {
    .input-with-select {
      position: relative;
      left: 20px;
      top: 20px;
      width: 376px;
      .el-select {
        width: 100px;
      }
    }
  }
</style>