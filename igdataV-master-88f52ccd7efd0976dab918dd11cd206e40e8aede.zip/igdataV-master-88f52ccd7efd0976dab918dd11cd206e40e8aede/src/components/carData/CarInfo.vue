<!--车辆搜索列表组件-->
<template>
    <div class="ui-carlist-container">
        <table class="ui-carlist-tab">
            <tbody>
            <tr>
                <td>
                    品牌：{{carInfo.band}}
                </td>
                <td>
                    故障状态：
                    <span v-if="carInfo.bad">有故障</span>
                    <span v-else>无故障</span>
                </td>
            </tr>
            <tr>
                <td>车辆类别：{{carInfo.type}}</td>
                <td>
                    能耗类型：
                    <span v-if="carInfo.energyType == 1">电动</span>
                    <span v-else-if="carInfo.energyType == 2">燃油</span>
                    <span  v-else-if="carInfo.energyType == 3">混动</span>
                </td>
            </tr>
            <tr>
                <td>归属：{{carInfo.owner}}</td>
                <td>车辆状态：
                    <!--0.待整备，1.已整备，2.运营中，3.报废-->
                    <span v-if="carInfo.status == 0">待整备</span>
                    <span v-else-if="carInfo.status == 1">已整备</span>
                    <span v-else-if="carInfo.status == 2">运营中</span>
                    <span v-else-if="carInfo.status == 3">报废</span>
                </td>
            </tr>
            <tr>
                <td colspan="2">ICCID：{{carInfo.iccid}}</td>
            </tr>
            <tr>
                <td colspan="2">车架号：{{carInfo.vin}}</td>
            </tr>
            </tbody>
        </table>
    </div>
</template>

<script>

    import {
        getCarInfoByVin
    } from "@/api/carData";

    export default {
        name: "CarInfo",
        data(){
            return {
                carInfo:""
            }
        },
        mounted(){
            this.getCarInfoByVin();
        },
        methods:{
            getCarInfoByVin(){
                //根据车牌号搜索车辆
                getCarInfoByVin({
                    vin:this.vin
                }).then((res) => {
                    this.carInfo =  res.results;

                    //自定义事件传递数据
                    this.$emit("infoReady",this.carInfo);
                });
            }
        },
        watch:{
            vin:function () {
                this.getCarInfoByVin();
            }
        },
        props: ["vin"]
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-carlist-tab{
          width: 100%;
          text-align: center;

          &>thead td{
              height: 40px;
              line-height: 40px;
              font-size: 18px;

              &:nth-child(1){
                  color: #0C7FFF;
              }
              &:nth-child(2){
                  color: #FFAA39;
              }
              &:nth-child(3){
                  color: #36A666;
              }
          }

          &>tbody td{
              height: 35px;
              line-height: 35px;
              font-size: 16px;
              color: #FFFFFF;
              text-align: left;
          }
      }
</style>
