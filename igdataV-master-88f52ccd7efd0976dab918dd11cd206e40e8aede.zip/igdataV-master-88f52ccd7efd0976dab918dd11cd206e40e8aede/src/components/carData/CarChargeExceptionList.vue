<!--车辆搜索列表组件-->
<template>
    <div class="ui-carlist-container">
        <p>
            以下车辆行驶能耗数据异常 ，百公里电耗
            上升过快，与对应车型均值差异明显
        </p>
        <table class="ui-carlist-tab">
            <thead>
            <tr>
                <td>车牌号</td>
                <td>车型</td>
            </tr>
            </thead>
            <tbody>
            <tr v-for="car in carList" :key="car.vin">
                <td>{{car.plate}}</td>
                <td>{{car.type}}</td>
            </tr>
            </tbody>
        </table>
        <footer class="ui-carlist-footer">
            <el-button type="primary"  @click="hideCarExceptionList()" style="background: linear-gradient(-90deg, #366EB6 0%, #414CA8 100%);border: 0;">收起列表</el-button>
        </footer>
    </div>
</template>

<script>
    import {
        getCars
    } from "@/api/carData";

    export default {
        name: "CarChargeExceptionList",
        data(){
            return {
                plate:"", //车牌搜索框的值
                isWidth0: true
            }
        },
        methods:{
            /**
             *  点击某一列之后，获取该车辆的数据，并通过自定义事件传递给父组件
             *
             * @param index
             */
            clickTrHander(index){
                //获得单击的车辆的数据
                let clickCarData = this.carList[index];

                //返回用户点击的车辆数据
                this.$emit("clickTr",clickCarData);
            },
            /**
             *  收起电耗异常车辆列表
             *
             */
            hideCarExceptionList(){
                //返回用户点击的车辆数据
                this.$emit("hideList");
            }
        },
        props: ['carList']
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-carlist-container{
        font-size: 14px;
    }

    .ui-carlist-tab{
        tr,td{
            border: 0;
        }
        width: 100%;
        text-align: center;
        border: 1px solid rgba(239,239,239,.13);

        tr.active>td{
            color: #0C7FFF;
        }

        &>thead td{
            height: 26px;
            line-height: 26px;
            font-size: 14px;

            &:nth-child(1){
                color: #0C7FFF;
            }
            &:nth-child(2){
                color: #FFAA39;
            }
            &:nth-child(3){
                color: #36A666;
            }
        }

        &>tbody{
            flex: 1;
        }

        &>tbody td{
            height: 26px;
            line-height: 26px;
            color: #FFFFFF;
        }

        tbody>tr:nth-child(odd){
            background: rgba(239,239,239,.04);
        }
    }
    .ui-carlist-footer{
        padding: 40px 0 20px 0;
        text-align: center;
    }
</style>
