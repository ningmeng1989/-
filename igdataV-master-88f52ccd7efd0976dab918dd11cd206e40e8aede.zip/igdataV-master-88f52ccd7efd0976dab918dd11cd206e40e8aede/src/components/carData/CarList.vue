<!--车辆搜索列表组件-->
<template>
    <div class="ui-carlist-container">
        <div class="ui-search-input-container">
            <input type="text" class="ui-search-input" v-model="plate" @keyup.enter="search" placeholder="  请输入车牌号">
        </div>
        <table class="ui-carlist-tab">
            <thead>
            <tr>
                <td>车牌号码</td>
                <td>车辆类别</td>
                <td>品牌</td>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(car, index) in carList" @click="clickTrHander(index)" :key="car.vin" :class="{active:car.vin === vinChecked}">
                <td>{{car.plate}}</td>
                <td>
                    <span v-if="car.commercial">商用车</span>
                    <span v-else>乘用车</span>
                </td>
                <td>{{car.band}}</td>
            </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
    import {
        getCars
    } from "@/api/carData";

    export default {
        name: "CarList",
        data(){
            return {
                carList:[], //车辆搜索结果列表
                carTop1:[], //车辆搜索结果列表 Top1
                allCarList:[], //所有车辆搜索结果
                plate:"", //车牌搜索框的值
                vinChecked:"", //当前选中车辆的 VIN
                isWidth0: true
            }
        },
        methods:{
            /**
             *  车辆搜索方法
             */
            search(){
                //得到参数
                let params = {
                    pageIndex:1,
                    pageSize:5,
                    plate:this.plate
                };

                //根据车牌号搜索车辆
                getCars(params).then((res) => {
                    //默认显示第一条数据
                    this.carTop1 = res.results.datas.slice(0,1);
                    //全部数据
                    this.allCarList = res.results.datas;

                    //根据当前prop 传递的参数，决定是显示一条数据，还是显示全屏数据
                    if(this.oneOrFull){
                        //显示第一条数据
                        this.carList = this.carTop1;
                    }else{
                        //显示全部数据
                        this.carList = this.allCarList;
                    }

                    //设置选中的车辆VIN
                    this.vinChecked =  this.carList[0].vin;

                    //返回第一辆车的车辆数据
                    this.$emit("clickTr",this.carList[0]);
                });
            },
            /**
             *  点击某一列之后，获取该车辆的数据，并通过自定义事件传递给父组件
             *
             * @param index
             */
            clickTrHander(index){
                //获得单击的车辆的数据
                let clickCarData = this.carList[index];

                //设置选中的车辆VIN
                this.vinChecked =  clickCarData.vin;

                //返回用户点击的车辆数据
                this.$emit("clickTr",clickCarData);
            }
        },
        mounted(){
            //进入页面默认搜索一遍
            this.search();
        },
        /**
         *  @params dataList
         *  @params oneOrFull   true|false   一条数据| 全屏分页展示
         *
         */
        props: ['dataList',"oneOrFull"],
        watch:{
            oneOrFull:function (val) {
                //根据当前传递的参数，决定是显示一条数据，还是显示全屏数据
                if(val){
                    //显示第一条数据
                    this.carList = this.carTop1;
                }else{
                    //显示全部数据
                    this.carList = this.allCarList;
                }
            }
        }
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-search-input{
        width: 100%;
        height: 40px;
        padding-left: 15px;

        border: 1px solid #343434;
        border-radius: 4px;

        background-color: rgba(0,0,0,0.29);


        font-size: 16px;
        color: #fff;
    }

    .ui-carlist-tab{
        width: 100%;
        text-align: center;

        tr.active>td{
            color: #0C7FFF;
        }

        &>thead td{
            height: 40px;
            line-height: 40px;
            font-size: 18px;

            &:nth-child(1){
                color: #0C7FFF;
            }
            &:nth-child(2){
                color: #FFAA39;
            }
            &:nth-child(3){
                color: #36A666;
            }
        }

        &>tbody{
            flex: 1;
        }

        &>tbody td{
            height: 40px;
            line-height: 40px;
            font-size: 16px;
            color: #FFFFFF;
        }
    }
</style>
