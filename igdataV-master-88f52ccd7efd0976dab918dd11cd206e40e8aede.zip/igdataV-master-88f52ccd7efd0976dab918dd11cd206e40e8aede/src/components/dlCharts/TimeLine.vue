<template>
    <div class="ui-drive-line">
        <header class="ui-title" v-if="title">
            <i class="ui-dot" :style="{background:mainColor}"></i>
            {{title}}
        </header>
        <div class="ui-drive-chart" id="J_carType" ref="J_carType">
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts';
    import colorUtils from '@/utils/colorUtils';
    import {
        chargingCount4time
    } from "@/api/powerData";

    //缓存定时器，以便于销毁
    let rechargeLoopTimer;

    export default {
        name: "DriveLine",
        data(){
            return {
                lineChart:"",
                timeNodes:""//时间节点数据

            }
        },
        methods:{
            initCarTypeCharts() {

                // let bar = echarts.init(this.$el);
                this.lineChart = echarts.init(this.$refs["J_carType"]);
                let option =  {
                    grid : {
                        top : 10,    //距离容器上边界10像素
                        bottom: 45,   //距离容器下边界25像素
                        left: 45,   //距离容器左边界45像素
                        right: 45   //距离容器右边界10像素
                    },
                    textStyle:{
                        color:"#fff"
                    },
                    calculable : true,
                    xAxis : [
                        {
                            type: 'time',
                            splitLine: {
                                lineStyle:{
                                    color: ['#161616'],
                                    width: 1,
                                    type: 'solid'
                                }
                            },
                            splitNumber:24,
                            splitArea:{
                                areaStyle:{
                                    color: [
                                        '#23242C'
                                    ]
                                }
                            }

                        }
                    ],
                    yAxis : [
                        {
                            type: 'value',
                            boundaryGap: [0, '100%'],
                            splitLine: {
                                lineStyle:{
                                    color: "rgba(255,255,255,0.05)",
                                    width: 1,
                                    type: 'solid'
                                }
                            },
                            splitArea:{
                                show:true,
                                areaStyle:{
                                    color: '#23242C'
                                }
                            }
                        }
                    ],
                    series : [
                        {
                            name:'邮件营销',
                            type: 'line',
                            showSymbol: false,
                            hoverAnimation: false,
                            color: [this.mainColor],
                            lineStyle: {
                                normal: {
                                    width: 4,
                                    color: {
                                        type: 'linear',
                                        x: 0,
                                        y: 1,
                                        x2: 1,
                                        y2: 0,
                                        colorStops: [{
                                            offset: 0, color: this.lineColor[0] // 0% 处的颜色
                                        }, {
                                            offset: 1, color: this.lineColor[1] // 100% 处的颜色
                                        }],
                                        globalCoord: false // 缺省为 false
                                    }
                                }
                            },
                            itemStyle: {
                                normal: {
                                    areaStyle: {
                                        type: 'default',
                                        color: {
                                            type: 'linear',
                                            x: 0,
                                            y: 1,
                                            x2: 1,
                                            y2: 0,
                                            colorStops: [{
                                                offset: 0, color: colorUtils.hexToRGBA(this.lineColor[0],0.12) // 0% 处的颜色
                                            }, {
                                                offset: 1, color: colorUtils.hexToRGBA(this.lineColor[1],0.12) // 100% 处的颜色
                                            }],
                                            globalCoord: false // 缺省为 false
                                        }
                                    }
                                }
                            },
                            smooth: true,
                            data:this.timeNodes
                        }
                    ]
                };
                this.lineChart.setOption(option);


                //设置24小时充电车辆数
                this.updateChargingCount4time({
                    "vehicleType":"CT00080"
                });

                //每5分钟更新一次
                rechargeLoopTimer = setInterval(()=>{
                    this.updateChargingCount4time({
                        "vehicleType":"CT00080",
                        "interval":-1
                    });
                },1200000)
            },
            /**
             * 更新24小时充电车辆数
             *
             */
            updateChargingCount4time(params){
                chargingCount4time(params).then((res) => {
                    //格式化一下数据，为 [1,2,3,88,5]
                    let formatData = res.results.map((element) => {
                        // return element.value;
                        let elementDate = new Date(element.time);
                        return {
                            name: elementDate.toString(),
                            value:[elementDate,element.value]
                        }
                    });

                    //如果是更新单个时间节点
                    if(params.interval === -1){
                        this.timeNodes.shift();
                        this.timeNodes.push(formatData[0]);

                        this.$emit("updateCount",formatData[0].value[1]);
                    }
                    //如果是初次设置 24个小时节点
                    else{
                        this.timeNodes = formatData;
                    }

                    //设置时间数据
                    this.lineChart.setOption({
                        series: [{
                            data: this.timeNodes
                        }]
                    });
                });
            }
        },
        mounted(){
            this.initCarTypeCharts();
        },
        destroyed(){
            //回收不需要的定时器，以节省资源
            clearInterval(rechargeLoopTimer);
        },
        props: ["title","mainColor","lineColor"]
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-drive-line{
        margin-top: 15px;
    }
    .ui-drive-chart{
        width: 100%;
        height: 200px;
    }
    .ui-dot{
        display: inline-block;

        position: relative;
        top: -3px;

        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #3a8ee6;
    }
    .ui-title{
        padding: 10px 0;
        font-size: 18px;
        letter-spacing:2px;
    }
</style>
