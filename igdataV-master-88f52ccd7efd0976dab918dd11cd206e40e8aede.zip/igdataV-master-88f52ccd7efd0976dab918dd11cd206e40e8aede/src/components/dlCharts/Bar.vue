<template>
    <div class="ui-drive-line">
        <header class="ui-title" v-if="title">
            <i class="ui-dot" :style="{background:mainColor}"></i>
            {{title}}
        </header>
        <div class="ui-drive-chart" id="J_carType" ref="J_carType">
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts';
    import colorUtils from '@/utils/colorUtils';

    export default {
        name: "DriveLine",
        data(){
            return {
            }
        },
        methods:{
            initCarTypeCharts(data) {
                // let bar = echarts.init(this.$el);
                let bar = echarts.init(this.$refs["J_carType"]);

                let option =  {
                    grid : {
                        top : 10,    //距离容器上边界10像素
                        bottom: 25,   //距离容器下边界25像素
                        left: 45,   //距离容器左边界45像素
                        right: 10   //距离容器右边界10像素
                    },
                    textStyle:{
                        color:"#fff"
                    },
                    calculable : true,
                    xAxis: {
                        type: 'category',
                        data: this.driveData.category
                    },
                    yAxis: {
                        type: 'value',
                        splitLine: {
                            lineStyle:{
                                color: "rgba(255,255,255,0.05)",
                                width: 1,
                                type: 'solid'
                            }
                        },
                        splitArea:{
                            show:true,
                            areaStyle:{
                                color: '#23242C'
                            }
                        }
                    },
                    series: [{
                        barWidth:15,
                        data: this.driveData.data,
                        type: 'bar',
                        itemStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(
                                    0, 0, 0, 1,
                                    [
                                        {offset: 0, color: this.lineColor[1]},
                                        {offset: 1, color: this.lineColor[0]}
                                    ]
                                )
                            }
                        }
                    }]
                };

                bar.setOption(option);
            }
        },
        watch:{
            "driveData":function () {
                this.initCarTypeCharts();
            }
        },
        mounted(){
            this.initCarTypeCharts();
        },
        props: ['driveData',"title","mainColor","lineColor"]
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-drive-line{
        margin-top: 15px;
    }
    .ui-drive-chart{
        width: 100%;
        height: 200px;
    }
    .ui-dot{
        display: inline-block;

        position: relative;
        top: -3px;

        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #3a8ee6;
    }
    .ui-title{
        padding: 10px 0;
        font-size: 18px;
        letter-spacing:2px;
    }
</style>
