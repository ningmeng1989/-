<template>
    <div class="ui-barlist min-font-style" v-bind:class="{ width0: isWidth0 }">
        <div v-for="element in dataList" class="ui-progress-item">
            <div class="ui-progress-left">
                <el-progress :show-text="false" :stroke-width="18" :percentage="element.percent" :color="element.color"></el-progress>
            </div>
            <div class="ui-progress-right">
                <el-tooltip class="item" effect="dark" :content="element.name" placement="top-start">
                    <span class="ui-group-name">{{element.name}}</span>
                </el-tooltip>
                <br>
                {{element.value}}
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "BarList",
        data(){
            return {
                isWidth0: true
            }
        },
        mounted(){
            setTimeout(() => {
                this.isWidth0 = false
            }, 1000);
        },
        props: ['dataList']
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-progress-item{
        margin-bottom: 10px;

        &>div{
            min-height: 15px;
        }



        .ui-progress-left{
            width: 100%;
            padding-right: 90px;
            margin-right: -90px;
            display: inline-block;
            vertical-align: top;
        }
        .ui-progress-right{
            margin-left: 10px;
            display: inline-block;

            font-size: 14px;

            vertical-align: top;
        }
    }
    .ui-progress-item:last-child{
        margin-bottom: 0;
    }
    .ui-group-name{
        display: inline-block;
        width: 70px;
        overflow: hidden;/*内容超出后隐藏*/
        text-overflow: ellipsis;/* 超出内容显示为省略号*/
        white-space: nowrap;/*文本不进行换行*/
    }
</style>

<style rel="stylesheet/scss" lang="scss" >
    .ui-barlist {
        .el-progress-bar__inner {
            transition: width 2s;
        }
    }

    .width0{
        .el-progress-bar__inner {
            width: 0 !important;
        }
    }

    .min-font-style{
        .el-progress__text{
            font-size: 13px!important;
            color: #fff;
        }
        .el-progress-bar__outer{
            background-color: #303755;
        }
    }

    .black-progress-circle{
        .el-progress-circle__track{
            /*stroke: #3d3e44;*/
            stroke: rgba(139,139,139,0.3);
        }

        .el-progress__text{
            font-size: 20px!important;
            color: #fff;
        }
    }
</style>