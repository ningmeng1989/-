<template>
    <div class="ui-drive-line">
        <header class="ui-title" v-if="title">
            <i class="ui-dot" :style="{background:mainColor}"></i>
            {{title}}
        </header>
        <div class="ui-drive-chart" id="J_carType" ref="J_carType">
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts';
    import colorUtils from '@/utils/colorUtils';

    export default {
        name: "DriveLine",
        methods:{
            initCarTypeCharts() {
                // let bar = echarts.init(this.$el);
                let bar = echarts.init(this.$refs["J_carType"]);

                let option =  {
                    grid : {
                        top : 10,    //距离容器上边界10像素
                        bottom: 25,   //距离容器下边界25像素
                        left: 45,   //距离容器左边界45像素
                        right: 10   //距离容器右边界10像素
                    },
                    textStyle:{
                        color:"#fff"
                    },
                    calculable : true,
                    xAxis : [
                        {
                            type : 'category',
                            boundaryGap : false,
                            // data : this.driveData.category||['周一','周二','周三','周四','周五','周六','周日']
                            data : this.driveData.category,
                            splitLine: {
                                lineStyle:{
                                    color: ['#161616'],
                                    width: 1,
                                    type: 'solid'
                                }
                            },
                            splitArea:{
                                areaStyle:{
                                    color: [
                                        '#23242C'
                                    ]
                                }
                            }
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value',
                            splitLine: {
                                lineStyle:{
                                    color: "rgba(255,255,255,0.05)",
                                    width: 1,
                                    type: 'solid'
                                }
                            },
                            splitArea:{
                                show:true,
                                areaStyle:{
                                    color: '#23242C'
                                }
                            }
                        }
                    ],
                    series : [
                        {
                            name:'邮件营销',
                            type:'line',
                            stack: '总量',
                            color: [this.mainColor],
                            symbol:"none",
                            smooth: true,
                            lineStyle: {
                                normal: {
                                    width: 0,
                                    color: {
                                        type: 'linear',
                                        x: 0,
                                        y: 1,
                                        x2: 1,
                                        y2: 0,
                                        colorStops: [{
                                            offset: 0, color: this.lineColor[0] // 0% 处的颜色
                                        }, {
                                            offset: 1, color: this.lineColor[1] // 100% 处的颜色
                                        }],
                                        globalCoord: false // 缺省为 false
                                    }
                                }
                            },
                            itemStyle: {
                                normal: {
                                    areaStyle: {
                                        type: 'default',
                                        color: {
                                            type: 'linear',
                                            x: 0,
                                            y: 1,
                                            x2: 1,
                                            y2: 0,
                                            colorStops: [{
                                                // offset: 0, color:"red" // 0% 处的颜色
                                                offset: 0, color:this.lineColor[0] // 0% 处的颜色
                                            }, {
                                                offset: 1, color:this.lineColor[1] // 100% 处的颜色
                                            }],
                                            globalCoord: false // 缺省为 false
                                        }
                                    },
                                    chordStyle:{
                                        color:"black"
                                    }
                                }
                            },
                            // data: this.driveData.data || [120, 132, 101, 134, 90, 230, 210],
                            data: this.driveData.data,
                            ribbonType:false,

                        }
                    ]
                };

                bar.setOption(option);
            }
        },
        mounted(){
            this.initCarTypeCharts();
        },
        watch:{
            "driveData":function (data) {
                this.initCarTypeCharts();
            }
        },
        props: ['driveData',"title","mainColor","lineColor"]
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-drive-line{
        margin-top: 15px;
    }
    .ui-drive-chart{
        width: 100%;
        height: 200px;
    }
    .ui-dot{
        display: inline-block;

        position: relative;
        top: -3px;

        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #3a8ee6;
    }
    .ui-title{
        padding: 10px 0;
        font-size: 18px;
        letter-spacing:2px;
    }
</style>
