<template>
    <div class="ui-drive-line">
        <header class="ui-title" v-if="title">
            <i class="ui-dot" :style="{background:mainColor}"></i>
            {{title}}
        </header>
        <div class="ui-drive-chart" id="J_carType" ref="J_carType">
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts';
    import colorUtils from '@/utils/colorUtils';
    import {
        chargingCount4time
    } from "@/api/powerData";


    let demoData = [];
    let now = +new Date(1997, 9, 3);
    let oneDay = 24 * 3600 * 1000;
    let value = Math.random() * 1000;
    for (let i = 0; i < 1000; i++) {
        demoData.push(randomData());
    }

    function randomData() {
        now = new Date(+now + oneDay);
        value = value + Math.random() * 21 - 10;

        return {
            name: now.toString(),
            value: [
                now,
                Math.round(value)
            ]
        }
    }

    export default {
        name: "DriveLine",
        data(){
            return {
                lineChart:"",
                timeNodes:""//时间节点数据

            }
        },
        methods:{
            initCarTypeCharts() {
/*                //设置24小时充电车辆数
                this.updateChargingCount4time({
                    "vehicleType":"CT00080"
                });

                //每10秒更新一次
                setInterval(()=>{
                    this.updateChargingCount4time({
                        "vehicleType":"CT00080",
                        "interval":-1
                    });
                },10000)*/

                let lineChart = echarts.init(this.$refs["J_carType"]);

                let option = {
                    grid : {
                        top : 10,    //距离容器上边界10像素
                        bottom: 45,   //距离容器下边界25像素
                        left: 45,   //距离容器左边界45像素
                        right: 45   //距离容器右边界10像素
                    },
                    textStyle:{
                        color:"#fff"
                    },
                    tooltip: {
                        trigger: 'axis',
                        formatter: function (params) {
                            params = params[0];
                            let date = new Date(params.name);
                            return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear() + ' : ' + params.value[1];
                        },
                        axisPointer: {
                            animation: false
                        }
                    },
                    xAxis: {
                        type: 'time',
                        splitLine: {
                            lineStyle:{
                                color: ['#111'],
                                width: 1,
                                type: 'solid'
                            }
                        }
                    },
                    yAxis: {
                        type: 'value',
                        boundaryGap: [0, '100%'],
                        splitLine: {
                            lineStyle:{
                                color: ['#161616'],
                                width: 1,
                                type: 'solid'
                            }
                        }
                    },
                    series: [{
                        name: '模拟数据',
                        type: 'line',
                        showSymbol: false,
                        hoverAnimation: false,
                        color: [this.mainColor],
                        lineStyle: {
                            normal: {
                                width: 4,
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 1,
                                    x2: 1,
                                    y2: 0,
                                    colorStops: [{
                                        offset: 0, color: this.lineColor[0] // 0% 处的颜色
                                    }, {
                                        offset: 1, color: this.lineColor[1] // 100% 处的颜色
                                    }],
                                    globalCoord: false // 缺省为 false
                                }
                            }
                        },
                        itemStyle: {
                            normal: {
                                areaStyle: {
                                    type: 'default',
                                    color: {
                                        type: 'linear',
                                        x: 0,
                                        y: 1,
                                        x2: 1,
                                        y2: 0,
                                        colorStops: [{
                                            offset: 0, color: colorUtils.hexToRGBA(this.lineColor[0],0.12) // 0% 处的颜色
                                        }, {
                                            offset: 1, color: colorUtils.hexToRGBA(this.lineColor[1],0.12) // 100% 处的颜色
                                        }],
                                        globalCoord: false // 缺省为 false
                                    }
                                }
                            }
                        },
                        data: demoData
                    }],
                    axis:{
                        splitLine:{
                            show:true,
                            lineStyle:{
                                color: ['#ccc'],
                                width: 3,
                                type: 'solid'
                            }
                        }
                    }
                };

                lineChart.setOption(option);

                setInterval(function () {

                    for (let i = 0; i < 5; i++) {
                        demoData.shift();
                        demoData.push(randomData());
                    }

                    lineChart.setOption({
                        series: [{
                            data: demoData
                        }]
                    });
                }, 5000);
            },
            /**
             * 更新24小时充电车辆数
             *
             */
            updateChargingCount4time(params){
                chargingCount4time(params).then((res) => {


                    // name:"Tue Feb 26 2058 00:00:00 GMT+0800 (中国标准时间)"
                    // value:Array(2)
                    // 0:"2058/2/26"
                    // 1:10227
                    //格式化一下数据，为 [1,2,3,88,5]
                    let formatData = res.results.map((element) => {
                        // return element.value;
                        return {
                            name: new Date(element.time).toString(),
                            value:["11:00",element.value]
                        }
                    });


                    //如果是更新单个时间节点
                    if(params.interval === -1){
                        this.timeNodes.shift();
                        this.timeNodes.push(formatData[0]);

                        this.lineChart.setOption({
                            series: [{
                                data: this.timeNodes
                            }]
                        });
                    }
                    //如果是初次设置 24个小时节点
                    else{
                        this.timeNodes = formatData;

                        // let bar = echarts.init(this.$el);
                        this.lineChart = echarts.init(this.$refs["J_carType"]);
                        let option =  {
                            textStyle:{
                                color:"#fff"
                            },
                            grid : {
                                top : 10,    //距离容器上边界10像素
                                bottom: 45,   //距离容器下边界25像素
                                left: 45,   //距离容器左边界45像素
                                right: 45   //距离容器右边界10像素
                            },
                            calculable : true,
                            xAxis: {
                                type: 'time',
                                splitLine: {
                                    show: false
                                }
                            },
                            yAxis: {
                                type: 'value',
                                boundaryGap: [0, '100%'],
                                splitLine: {
                                    show: false
                                }
                            },
                            series: [{
                                name: '模拟数据',
                                type: 'line',
                                showSymbol: false,
                                hoverAnimation: false,
                                color: [this.mainColor],
                                lineStyle: {
                                    normal: {
                                        width: 4,
                                        color: {
                                            type: 'linear',
                                            x: 0,
                                            y: 1,
                                            x2: 1,
                                            y2: 0,
                                            colorStops: [{
                                                offset: 0, color: this.lineColor[0] // 0% 处的颜色
                                            }, {
                                                offset: 1, color: this.lineColor[1] // 100% 处的颜色
                                            }],
                                            globalCoord: false // 缺省为 false
                                        }
                                    }
                                },
                                itemStyle: {
                                    normal: {
                                        areaStyle: {
                                            type: 'default',
                                            color: {
                                                type: 'linear',
                                                x: 0,
                                                y: 1,
                                                x2: 1,
                                                y2: 0,
                                                colorStops: [{
                                                    offset: 0, color: colorUtils.hexToRGBA(this.lineColor[0],0.12) // 0% 处的颜色
                                                }, {
                                                    offset: 1, color: colorUtils.hexToRGBA(this.lineColor[1],0.12) // 100% 处的颜色
                                                }],
                                                globalCoord: false // 缺省为 false
                                            }
                                        }
                                    }
                                },
                                data: formatData
                            }]
                        };
                        this.lineChart.setOption(option);

                    }

                    console.log("看看 Time line res");
                    console.log(formatData);

                });
            }
        },
        mounted(){
            this.initCarTypeCharts();
        },
        props: ["title","mainColor","lineColor"]
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-drive-line{
        margin-top: 15px;
    }
    .ui-drive-chart{
        width: 100%;
        height: 200px;
    }
    .ui-dot{
        display: inline-block;

        position: relative;
        top: -3px;

        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #3a8ee6;
    }
    .ui-title{
        padding: 10px 0;
        font-size: 18px;
        letter-spacing:2px;
    }
</style>
