<template>
    <div class="ui-drive-line">
        <header class="ui-title" v-if="title">
            <i class="ui-dot" :style="{background:mainColor}"></i>
            {{title}}
        </header>
        <div class="ui-drive-chart" id="J_carType" ref="J_carType">
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts';
    import colorUtils from '@/utils/colorUtils';

    export default {
        name: "BarStack",
        data(){
            return {
            }
        },
        methods:{
            initCarTypeCharts() {
                let bar = echarts.init(this.$refs["J_carType"]);

                let option =  {
                    grid : {
                        top : 0,    //距离容器上边界10像素
                        bottom: 25,   //距离容器下边界25像素
                        left: -30,   //距离容器左边界45像素
                        right: 10,   //距离容器右边界10像素
                        containLabel:true
                    },
                    textStyle:{
                        color:"#fff"
                    },
                    tooltip : {
                        trigger: 'axis',
                        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                        }
                    },
                    xAxis:  {
                        type: 'category',
                        data: this.driveData.category
                    },
                    yAxis: {
                        type: 'value',
                        // x轴的字体样式
                        axisLabel: {
                            show: false,
                            margin:0
                        },
                        splitLine: {
                            lineStyle:{
                                color: "rgba(255,255,255,0.05)",
                                width: 1,
                                type: 'solid'
                            }
                        },
                        splitArea:{
                            show:true,
                            areaStyle:{
                                color: '#23242C'
                            }
                        }
                    }
                };

                //总数数组
                let totalArr = this.driveData.total;

                //动态计算
                option.series = this.driveData.data.map((element, index) => {

                    //根据总数数组，分别计算每一个value 占有的百分比
                    let percentVals = element.values.map((valElement, valIndex) => {
                        //如果总数为0，就不处理直接返回0
                        if (totalArr[valIndex] === 0){
                            return 0;
                        }
                        //如果不为0，就计算当前数值，占总数的百分比
                        else{
                            return  Math.round(valElement / totalArr[valIndex] * 100);
                        }
                    });

                    //每一个对象的模板
                    return  {
                        barWidth:15,
                        name: `${element.level}级报警`,
                        type: 'bar',
                        stack: '报警',
                        itemStyle: {
                            normal: {
                                color: this.lineColor[index]
                            }
                        },
                        data: percentVals
                    }

                });


                bar.setOption(option);
            }
        },
        watch:{
            "driveData":function () {
                console.log("driveDatadriveData");
                console.log(this.driveData);
                this.initCarTypeCharts();
            }
        },
        mounted(){
            this.initCarTypeCharts();
        },
        props: ['driveData',"title","mainColor","lineColor"]
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-drive-line{
        margin-top: 15px;
    }
    .ui-drive-chart{
        width: 100%;
        height: 200px;
    }
    .ui-dot{
        display: inline-block;

        position: relative;
        top: -3px;

        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #3a8ee6;
    }
    .ui-title{
        padding: 10px 0;
        font-size: 18px;
        letter-spacing:2px;
    }
</style>
