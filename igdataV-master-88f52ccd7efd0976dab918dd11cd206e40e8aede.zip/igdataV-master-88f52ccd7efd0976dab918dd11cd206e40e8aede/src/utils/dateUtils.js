

// 日期时间格式化
Date.prototype.format = function (t) {
    if(!this)return;
    let arr = {
        'y+': this.getFullYear(),//年
        'M+': this.getMonth() + 1,//月份
        'd+': this.getDate(),//日
        'h+': this.getHours(),//小时
        'm+': this.getMinutes(),//分
        's+': this.getSeconds(),//秒
        'q+': Math.floor((this.getMonth() + 3) / 3),//季度
        'w+': this.getDay(), //星期
        'S+': this.getMilliseconds()//毫秒
    };
    let d = t || 'yyyy-MM-dd hh:mm:ss';
    for (let i in arr) {
        if (new RegExp('(' + i + ')').test(d)) {
            let s = '' + arr[i], n = RegExp.$1.length - s.length;
            d = d.replace(RegExp.$1, n > 0 ? new Array(n + 1).join('0') + s : s);
        }
    }
    return d;
};

export default {};