<template>
    <div class="ui-container">
        <!-- 顶部菜单 -->
        <TopHeader headTitle="综合数据分析" :btns="[{value:'返回',to:'/'}]"></TopHeader>
        <!-- /顶部菜单 -->

        <!-- 左侧菜单面板 -->
        <section class="ui-left-panel ui-lr-panel">
            <div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    机构车辆数TOP 6
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <BarList :dataList="carTop6"></BarList>
                    <div class="ui-progress-foot">单位（辆）</div>
                </div>
            </div>
            <div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    车型占比
                </header>
                <div class="ui-panel-item-content">
                    <div style="width: 100%;height:220px;margin: auto;" id="J_carType" ref="J_carType">
                    </div>
                </div>
            </div>
            <div class="ui-item-panel ui-count-data">
                <dl class="ui-panel-item-content">
                    <dd>
                        <span class="ui-count-title">车辆总数</span>
                        <span class="ui-count-num" id="J_carCount" style="color: #47A4FF;"></span> 辆
                    </dd>
                    <dd>
                        <span class="ui-count-title">当前在线</span>
                        <span class="ui-count-num" id="J_onlineCount" style="color: #E29A23;"></span> 辆
                    </dd>
                    <dd>
                        <span class="ui-count-title">累计行驶时长</span>
                        {{totalOnlineTimeCount}} 小时
                    </dd>
                    <dd>
                        <span class="ui-count-title">累计行驶里程</span>
                        {{totalTravelMileageCount}} 万公里
                    </dd>
<!--                    <dd>
                        <span class="ui-count-title">新能源里程</span>
                        <span class="ui-count-num" style="color: #47A4FF;"></span>
                    </dd>
                    <dd>
                        <span class="ui-count-title">减少碳排放</span>
                        <span class="ui-count-num" style="color: #47A4FF;"></span>
                    </dd>-->
                </dl>
            </div>
        </section>
        <!-- /左侧菜单面板 -->

        <!-- 右侧菜单面板 -->
        <section class="ui-right-panel ui-lr-panel">
            <div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    机构车辆平均在线时长 TOP6
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <BarList :dataList="timeTop6"></BarList>
                    <div class="ui-progress-foot">单位（小时）</div>
                </div>
            </div>

            <div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    月度报警类型占比
                </header>
                <div class="ui-panel-item-content">
                    <div class="ui-month-panel min-font-style">
                        <div v-for="alert in alertTop6" class="ui-month-col">
                            <div class="ui-rotate-wrap">
                                <div class="ui-rotate-line">
                                    <div class="ui-rotate-point" :style="{ background: alert.color }">
                                    </div>
                                </div>
                                <el-progress :width=82 type="circle" :percentage="alert.percent" :color="alert.color"
                                             class="black-progress-circle">
                                </el-progress>
                            </div>

                            <el-tooltip class="item" effect="dark" :content="alert.name" placement="top">
                                <div class="ui-p-circle-title">{{alert.name}}</div>
                            </el-tooltip>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /右侧菜单面板 -->


        <!-- 背景地图 -->
        <div class="map-container" id="map-container"></div>
        <!-- /背景地图 -->
    </div>
</template>

<script>
    import echarts from 'echarts';
    import CountUp from 'countup';
    import BarList from "@/components/dlCharts/BarList.vue"
    import TopHeader from "@/views/TopHeader.vue"
    // import AMap from 'vue-amap';
    import dateUtils from '@/utils/dateUtils';
    import {
        getVehicleCount,
        getOnlineVehicleCount,
        onlineTimeAscription,
        alertTypeByDate,
        vehicleProportion,
        vehiclePolymerization,
        totalOnlineTime,
        totalTravelMileage,
        getVehicleAscription
    } from "@/api/synthesize";


    //颜色集合
    let colorMap = {
        "0":"rgb(255, 96, 95)",
        "1":"rgb(255, 221, 80)",
        "2":"rgb(91, 167, 255)",
        "3":"rgb(146, 218, 255)",
        "4":"rgb(146, 218, 255)",
        "5":"rgb(146, 218, 255)"
    };

    //报警颜色集合
    let alertColorMap = {
        "0":"#0FA3FF",
        "1":"#FF5350",
        "2":"#3CE18B",
        "3":"#8e71c7",
        "4":"#FF7300",
        "5":"#675DDE"
    };


    //地图车辆图标颜色集合
    let carColorMap = {
        "1":"47,139,255",
        "2":"192,182,0",
        "3":"0,170,95"
    };

    //缓存地图
    let map;
    let mapTimer;

    let districtCluster;



    export default {
        name: "add-cars",
        data() {
            return {
                map: "",
                //机构车辆数TOP 6
                carTop6: [],
                //机构在线时长TOP 6
                timeTop6: [],
                alertTop6: [],
                //当前的行政区域聚合
                distCluster: "",
                //车辆总数
                carCount: 0,
                //当前在线总数
                onlineCount: 0,
                //行驶总时长统计
                totalOnlineTimeCount: 0,
                //行驶总时长统计
                totalTravelMileageCount: 0,
                mapTimer: ""
            }
        },
        mounted(){
            this.loadDistrictCluster();
            this.initCarTop6();
            this.initTimeTop6();
            this.initAlertTop6();
            this.initCarType();


            //初始化车辆总数
            this.setVehicleCount();

            //设置车辆在线总数
            this.setOnlineVehicleCount();

            //行驶总时长
            this.totalOnlineTime();

            //行驶总里程
            this.totalTravelMileage();

            //初始化地图逻辑
            this.initMap();

        },
        methods: {
            loadDistrictCluster(){
                //加载DistrictCluster，loadUI的路径参数为模块名中 'ui/' 之后的部分
                AMapUI.loadUI(['geo/DistrictCluster'], function(DistrictCluster) {
                    districtCluster = DistrictCluster;
                });
            },
            mapChange(){
                //坐标点集合
                // let points = this.getLngLat(map);
                //默认全国数据
                let points = {
                    lngMax:135.05,
                    lngMin:73.33,
                    latMax:53.33,
                    latMin:3.51
                };

                let params = Object.assign(points, {
                    "precisionGrade": 2,
                    "needVin": false
                })

                vehiclePolymerization(params).then((res) => {
                    //加载DistrictCluster，loadUI的路径参数为模块名中 'ui/' 之后的部分
                    AMapUI.loadUI(['geo/DistrictCluster'], (DistrictCluster) => {
                        this.distCluster = new DistrictCluster({
                            map: map, //所属的地图实例
                            //返回数据项中的经纬度位置
                            getPosition: function (item) {
                                return [item.lng, item.lat];
                            },
                            renderOptions: {
                                //直接定义某写区划面的样式
                                getFeatureStyle: function () {
                                    return {
                                        fillStyle: 'rgba(0,0,0,0)',
                                        lineWidth: 0, //描边线宽
                                        strokeStyle: 'rgba(0, 0, 0,0)',//描边色};
                                        //鼠标Hover后的样式
                                        hoverOptions: {
                                            fillStyle: 'rgba(0,0,0,0)',
                                            lineWidth: 0, //描边线宽
                                            strokeStyle: 'rgba(0, 0, 0,0)'//描边色};
                                        }
                                    }
                                },
                                getClusterMarker: (feature, dataItems, recycledMarker) => {

                                    //label内容
                                    let count = 0;
                                    dataItems.forEach((element) => {
                                        count += element.dataItem.count;
                                    });

                                    //如果当前行政区没有车辆，就直接过滤掉该区域
                                    if (count === 0) {
                                        return "";
                                    }

                                    let randomBaseColor = this.getColorByRandom();

                                    /* 6、光标点显示规则：按车辆数分别对省、市、区县进行排名，在省/市/区县三级视图红，
                                          按照排名显示不同的图标：前30%为黄色（大图标），
                                          中间30%为绿色（中等图标），后40%为蓝色（小图标）*/

                                    //只有省级一下才显示 label ，经过测试得出 5-8 level 为省级
                                    let content = "";
                                    let label = {};

                                    if (map.getZoom() >= 6) {
                                        // var content =feature.properties.name+' ('+dataItems.length+')' +"<span style='color:red;'>aaa</span>";
                                        content = `<div class="ui-carcount-window" style="color: rgb(${randomBaseColor.color})">
                                          <div class="ui-car-icon">  <img src="/static/img/synthesize/${randomBaseColor.index}.png" alt=""> </div>
                                          <div class="ui-car-count">${count}</div>
                                          <div class="ui-car-name">${feature.properties.name}</div>
                                     </div>`;

                                        label = {
                                            offset: new AMap.Pixel(-25, -50), //修改label相对于marker的位置
                                            content: content
                                        };
                                    } else {
                                        label = {
                                            content: ""
                                        }
                                    }



                                    //存在可回收利用的marker
 /*                                   if (recycledMarker) {
                                        console.log(recycledMarker);
                                        //直接更新内容返回
                                        recycledMarker.setLabel(label);
                                        return recycledMarker;
                                    }*/

                                    //动态生成 marker content
                                    let markerContent = this.genMarkerContent(randomBaseColor.color);

                                    //返回一个新的Marker
                                    return new AMap.Marker({
                                        label: label,
                                        offset: new AMap.Pixel(-50, -50), //修改label相对于marker的位置
                                        content: markerContent
                                    });
                                },
                                clusterMarkerKeepConsistent:false
                            }
                        });
                        //设置数据
                        this.distCluster.setData(res.results);

                        //设置地图缩放等级
                        map.setZoom(6);
                    });
                });
            },
            /**
             *  地图发生变化的时候的回调
             *
             * */
            initMap(){
                //初始化地图并缓存
                map = new AMap.Map('map-container', {
                    center: [116.397428, 39.90923],
                    resizeEnable: true,
                    // mapStyle:"amap://styles/blue",
                    mapStyle:"amap://styles/54546496cdede0811f122a8ef6a48ecf",
                    zooms:[3,18]
                });

                //先触发一下地图的数据更新
                this.mapChange();
/*                map.on('moveend', (e) => {
                    console.log(map.getZoom());
                });*/


            },
            /**
             *  返回当前地图可视窗口的坐标
             *
             * */
            getLngLat(map) {

                let lngLatStr = map.getBounds().toString();
                let lngLatArr = lngLatStr.split(/,|;/);

                return {
                    lngMax:lngLatArr[0],
                    lngMin:lngLatArr[1],
                    latMax:lngLatArr[2],
                    latMin:lngLatArr[3]
                }

            },
            /**
             *  格式化区域聚合数据，算出颜色，图标大小等等
             *
             * */
            formatAreaData(data) {

                let lngLatStr = map.getBounds().toString();
                let lngLatArr = lngLatStr.split(/,|;/);

                return {
                    lngMax:lngLatArr[0],
                    lngMin:lngLatArr[1],
                    latMax:lngLatArr[2],
                    latMin:lngLatArr[3]
                }

            },
            initTimeTop6(){
                onlineTimeAscription({"limit":6}).then((res) => {
                    //格式化数据
                    this.timeTop6 = this.top6FormatData(res.results.slice(0,6));
                });

            },
            initCarTop6(){
                getVehicleAscription({"limit":6}).then((res) => {
                    //格式化数据
                    this.carTop6 = this.top6FormatData(res.results.slice(0,6));
                });
            },
            initAlertTop6(){
                //测试数据
                alertTypeByDate().then((res) => {
                    //格式化数据
                    this.alertTop6 = this.alertDataFormat(res.results.slice(0,6));
                });

            },
            /**
             *  初始化车辆总数的数据逻辑
             * */
            setVehicleCount(){

                getVehicleCount().then((res) => {
                    //动态更新车辆总数
                    // this.carCount = res.results;
                    this.updateCountUp(res.results, "J_carCount");
                });

            },
            /**
             *  初始化在线车辆总数的数据逻辑
             * */
            setOnlineVehicleCount(){

                getOnlineVehicleCount().then((res) => {
                    // this.onlineCount = res.results;
                    //动态更新当前在线总数
                    // this.carCount = res.results;
                    this.updateCountUp(res.results, "J_onlineCount");
                });

            },
            /**
             *  行驶总时长查询
             * */
            totalOnlineTime(){

                totalOnlineTime().then((res) => {
                    //行驶总时长总数  毫秒转小时
                    this.totalOnlineTimeCount = Math.round(res.results / 3600000);
                    // this.totalOnlineTimeCount = res.results / 3600000;
                });

            },
            /**
             *  行驶总时长查询
             * */
            totalTravelMileage(){

                totalTravelMileage().then((res) => {
                    //行驶总时长总数  单位： 万公里
                    this.totalTravelMileageCount = (res.results / 10000).toFixed(2);
                });

            },
            /**
             *  渐进动画更新数字
             *
             *  @param  value   需要渐进更新的值
             *  @param  containerId   容器ID
             * */
            updateCountUp(value,containerId){

                //options 配置
                var options = {
                    useEasing: true,
                    useGrouping: true,
                    separator: ',',
                    decimal: '.',
                };

                //countUp 构造函数
                var countUpObj = new CountUp(containerId, 0, value, 0, 5, options);
                if (!countUpObj.error) {
                    countUpObj.start();
                } else {
                    console.error(countUpObj.error);
                }
            },
            /**
             *  初始化车型占比
             *
             * */
            initCarType(){
                vehicleProportion().then((res) => {
                    //当前在线总数
                    this.initCarTypeCharts(res.results);
                });
            },
            initCarTypeCharts(data) {

                //加上提示文字的样式
                let chartsData = data.map((element)=>{
                    return Object.assign(element,{
                        label:{
                            normal:{
                                formatter: '{b}\n{c}',
                                color:"#fff",
                                fontSize:14
                            }
                        }
                    });
                });

                // let bar = echarts.init(this.$el);
                let bar = echarts.init(this.$refs["J_carType"]);
                let option = {
/*                    tooltip : {
                        trigger: 'item',
                        formatter: "{c}<br>{b} ：({d}%)"
                    },*/
                    grid:{
                        x:100
                    },
                    series : [
                        {
                            type: 'pie',
                            color: ['#FFA52D','#1680C0','#3dbbff','#ECDF0E','#536CF7','#76EDBD'],
                            center: ['50%', '50%'],
                            selectedMode: 'single',
                            data:chartsData,
                            itemStyle: {
                                emphasis: {
                                    shadowBlur: 10,
                                    shadowOffsetX: 0,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                            }
/*                            ,
                            roseType: 'radius',
                            animationType: 'scale',
                            animationEasing: 'elasticOut'*/
                        }
                    ]
                };
                bar.setOption(option);
            },
            onSubmit() {
                console.log('submit!');
            },
            /**
             *  TOP6 数据的格式化
             *
             *  @param carTop6
             *  @return {Array}  carTop6  格式化之后的数据
             *
             * */
            top6FormatData(carsTop6) {
                //首先降序排序
                let carTop6 = carsTop6.sort(this.compare("value"));

                //设置颜色
                carTop6 = this.setColorByIndex(carTop6, colorMap);

                //设置百分比
                carTop6 = this.setPercent(carTop6, carTop6[0].value);

                return carTop6;
            },
            /**
             *  报警数据的格式化
             *
             *  @param data
             *
             * */
            alertDataFormat(data) {

                //设置颜色
                data = this.setColorByIndex(data, alertColorMap);

                //统计分母
                let count = 0;
                data.forEach((element)=>{
                    count += element.value;
                });

                //设置百分比
                data = this.setPercent(data, count);

                return data;
            },
            compare(property) {
                return function (obj1, obj2) {
                    let value1 = obj1[property];
                    let value2 = obj2[property];
                    return value2 - value1;     // 降序
                }
            },
            /**
             * 设置进度条颜色
             *
             * @param carTop6
             * @param colorMap  颜色集合
             */
            setColorByIndex(carTop6 , colorMap) {

                //遍历数据设置颜色
                let newCarTop6 = carTop6.map((element,index)=>{

                    element.color = colorMap[index];
                    return element;
                });

                return newCarTop6;
            },
            /**
             * 设置进度条百分比
             *
             * @param carTop6
             * @param denominator  分母
             *
             */
            setPercent(carTop6, denominator) {

                //遍历数据设置百分比
                let newCarTop6 = carTop6.map((element) => {
                    element.percent = parseFloat((element.value / denominator * 100).toFixed(1));
                    return element;
                });

                return newCarTop6;
            },
            /**
             *  随机获取一个颜色
             *
             * */
            getColorByRandom(){
                let randomNum = this.random(1,3);

                return {
                    index: randomNum,
                    color: carColorMap[randomNum],
                };
            },
            /**
             *  随机获取动画的延迟时间
             *
             *  @return {Array}    [oneStartDelay,twoStartDelay]   两个动画开始的时间
             *
             * */
            getDelayByRandom(){
                //个位
                let unit  = this.random(1,4);
                //十位
                let tens  = this.random(1,4);

                let oneStartDelay = parseInt(`${tens}${unit}`)/10;
                let twoStartDelay = oneStartDelay + 0.3;

                return [oneStartDelay,twoStartDelay];
            },
            /**
             * 产生随机整数，包含下限值，包括上限值
             * @param {Number} lower 下限
             * @param {Number} upper 上限
             * @return {Number} 返回在下限到上限之间的一个随机整数
             */
            random(lower, upper) {
                return Math.floor(Math.random() * (upper - lower + 1)) + lower;
            },
            /**
             *    生成基础点坐标的内容
             * @param {String} baseColor 基础颜色
             */
            genMarkerContent(baseColor) {
                //随机获得动画延迟时间
                let delays = this.getDelayByRandom();

                let content = `<div class="wave solid warning">
                                    <div class="circle" style="background:rgb(${baseColor});animation-delay:${delays[0]}s"></div>
                                    <div class="circle" style="background:rgb(${baseColor});animation-delay:${delays[1]}s"></div>
                                    <div class="content">
                                        <div class="min-circle" style="background:rgb(${baseColor})"></div>
                                    </div>
                               </div>`;
                return content;
            }
        },
        components:{BarList,TopHeader}
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    @import "src/styles/mixin.scss";

    .ui-logo{
        margin: 20px 40px;

    }

    dl {
        margin: 0;
        & > dd {
            margin: 0;
        }
    }



    $lightBlue:#47A4FF;
    $mangoYello:#FFAA39;

    .ui-container{
        font-family: PingFangSC-Semibold;
        position: relative;

        width: 100%;
        height: 100%;

        // 关于模块背景色的样式
        @mixin black-style {
            background: rgba(36,38,50,.73);
        }






        .ui-lr-panel{
            display: flex;

            position: absolute;
            bottom: 0;
            left: 0;

            z-index: 2;

            /*width: 440px;*/
            width: 20%;

            padding: 15px;

            flex-direction:column-reverse;


            .ui-item-panel{
                position: relative;

                margin-top: 15px;

                border: 1px solid #3d3d3e;
                border-radius: 2px;

                .ui-panel-item-title{
                    display: block;
                    height: 45px;
                    padding: 10px 15px;
                    padding-right: 50px;
                    color: #fff;

                    font-size: 22px;
                    @include black-style;
                }
                .ui-panel-item-content{
                    @include black-style;
                    color: #ffffff;

                    padding: 15px;

                    border-radius: 0 2px 2px 2px;
                }
            }
        }

        .ui-left-panel{

        }

        .ui-right-panel{
            left: auto;
            right: 0;
        }

        .map-container{
            width: 100%;
            height: 100%;
        }

        .ui-count-title{
            margin-right: 30px;
            /*margin-left: 50px;*/
        }
    }
    .el-progress{
    }
    .ui-progress-foot{
        margin-top: -10px;
        font-size: 13px;
    }
    .ui-month-panel{

        @include clearfix;

        .ui-month-col{
            width: 33.333%;
            display: inline-block;
            float: left;

            text-align: center;
        }


    }



    .ui-p-circle-title{
        margin: 10px 0;
        font-size: 16px;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        word-break: break-all;
    }



    .ui-count-data{
        font-family: PingFangSC-Semibold;
        font-size: 18px;
        color: #fff;

        border: 1px solid #3d3d3e;
        border-radius: 2px;

        dl>dd{
            padding: 5px;

            &>*{
                display: inline-block;
                /*line-height: 40px;*/

            }

            &>.ui-count-num{
                position: relative;
                top: 3px;

                font-size: 22px;
            }
        }
    }

    .ui-count-icon{
        position: relative;
        top: 5px;
    }

    /** 旋转的小点实现 **/
    .ui-rotate-wrap{
        position: relative;

        display: inline-block;
    }
    .ui-rotate-line{
        border-radius: 50%;
        position: absolute;
        z-index: 200;
        top: -7%;
        left: 50%;
        margin-left: -5px;
        width: 8px;
        height: 57%;
        transform-origin: 50% 100%;
        transform: rotate(-105deg);
        /* animation: rotate3D 5s both ease-in-out alternate; */
        /*animation: rotate3D-data-v-3c568bc2 5s both infinite;*/
        animation: rotate3D 10s linear infinite;
        opacity: 0.75;
    }
    .ui-rotate-point {
        position: absolute;
        left: 50%;
        top: 0%;
        height: 6px;
        width: 6px;
        border-radius: 50%;
        transform: translate(-50%, -50%) rotate(45deg);
    }

    @keyframes rotate3D {
        0% {
            transform: rotate3D(0, 0, 1, -105deg);
        }
        to {
            transform: rotate3D(0, 0, 1, 255deg);
        }
    }


</style>

<style rel="stylesheet/scss" lang="scss">


    .amap-marker-label {
        background: rgba(37,41,61,0.68);
        border: 1px solid rgba(61,61,62,0.68);
        border-radius: 4px;
        font-size: 15px;
        color: #fff;
        width: 150px;
        /*min-height: 70px;*/
        text-align: center;
    }
    .ui-carcount-window{
        position: relative;
        &>.ui-car-count,&>.ui-car-name{
            height: 20px;
            line-height: 20px;
        }

        &>.ui-car-icon{
            position: absolute;
            top: 3px;
            left: 5px;

            width: 20px;
            height: 20px;

            img{
                width: 100%;
            }
        }
    }

    /************以下为具体实现************/

    .wave {
        position: relative;
        width: 100px;
        height: 100px;
        text-align: center;
        line-height: 100px;
        font-size: 28px;
    }

    .wave .circle {
        position: absolute;
        border-radius: 50%;
    }



    /* 波动效果 */

    .wave.solid .circle {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        margin: auto;
    }

    .wave.solid .circle:first-child {
        width: 60%;
        height: 60%;
        animation: circle-opacity 3s infinite alternate;
        opacity: 0.2;

    }

    .wave.solid .circle:nth-child(2) {
        width: 100%;
        height: 100%;
        animation: circle-opacity 3s infinite alternate;
        /*animation-delay: .3s;*/
        opacity: 0.09;
    }


    .min-circle {
        width: 16px;
        height: 16px;
        border-radius: 50%;

        margin: auto;
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
    }

    @keyframes circle-opacity {
        from {
            transform: scale(1);
        }
        to {
            transform: scale(0.8);
        }

    }
</style>