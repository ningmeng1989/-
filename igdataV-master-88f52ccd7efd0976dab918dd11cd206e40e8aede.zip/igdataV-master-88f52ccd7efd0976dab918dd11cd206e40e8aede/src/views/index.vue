<template>
    <div class="container">
        <!-- 顶部菜单 -->
        <TopHeader :btns="[{value:'退出',to:'/logout'}]"></TopHeader>
        <!-- /顶部菜单 -->
        <div class="ui-page-content">
            <el-row>
                <el-col :span="6">
                    <router-link to="/synthesize">
                        <div class="ui-menu-container">
                            <img src="/static/img/home/1.png" class="ui-menu-icon"/>
                            <div class="ui-link-container">
                                <input type="button" class="ui-link-btn" value="综合数据分析">
                            </div>
                            <div class="ui-description">
                                综合分析联网车辆全局数据
                            </div>
                        </div>
                    </router-link>
                </el-col>
                <el-col :span="6">
                    <router-link to="/carData">
                        <div class="ui-menu-container">
                            <img src="/static/img/home/2.png" class="ui-menu-icon"/>
                            <div class="ui-link-container">
                                <input type="button" class="ui-link-btn" value="单车数据分析">
                            </div>
                            <div class="ui-description">
                                挖掘分析单车日常行驶数据
                            </div>
                        </div>
                    </router-link>
                </el-col>
                <el-col :span="6">
                    <router-link to="/powerData">
                        <div class="ui-menu-container">
                            <img src="/static/img/home/3.png" class="ui-menu-icon"/>
                            <div class="ui-link-container">
                                <input type="button" class="ui-link-btn" value="动力数据分析">
                            </div>
                            <div class="ui-description">
                                分析车型动力模块相关数据
                            </div>
                        </div>
                    </router-link>
                </el-col>
                <el-col :span="6">
                    <router-link to="/malfunction">
                        <div class="ui-menu-container">
                            <img src="/static/img/home/4.png" class="ui-menu-icon"/>
                            <div class="ui-link-container">
                                <input type="button" class="ui-link-btn" value="故障数据分析">
                            </div>
                            <div class="ui-description">
                                分析车型故障报警数据
                            </div>
                        </div>
                    </router-link>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
    import TopHeader from "@/views/TopHeader.vue";

    export default {
        name: "index",
        components:{TopHeader}
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .container{
        background: linear-gradient(to bottom, #161519 , #000); /* 标准的语法（必须放在最后） */
        height: 100%;

        display:flex;
        align-items: center;/*垂直居中*/
        justify-content: center;/*水平居中*/
    }

    .ui-page-logo{
        position: absolute;
        top: 5%;
        left: 10%;
        font-size: 40px;
        color: #fff;
    }

    .ui-menu-icon{
        position: relative;
        top: 0;

        width: 100%;
    }

    .ui-link-btn{
        display: block;
        margin: auto;
        padding: 8px 20px 10px 20px;
        border: 0;
        background: url("/static/img/home/btn_back.png") no-repeat;
        background-size: 100% 100%;

        font-size: 24px;
        color: #fff;
        text-align: center;
        letter-spacing:2px;

        cursor:pointer;
    }

    .ui-menu-container{
        position: relative;
        top: 0;
        transition: all 0.2s ease-in;

        &:hover{
            top: -5px;
        }
    }

    .ui-description{
        margin-top: 20px;
        color: #a0a0c0;
        font-size: 24px;
        text-align: center;
    }

    .bg-purple{
        font-size: 30px;
        color: #fff;
    }

    @keyframes ghostUpdown{
        from{top:0;}
        to{top:-25px;}
    }


</style>