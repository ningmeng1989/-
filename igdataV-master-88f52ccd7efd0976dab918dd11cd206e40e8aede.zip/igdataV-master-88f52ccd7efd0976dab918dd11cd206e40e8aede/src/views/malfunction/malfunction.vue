<template>
    <div class="ui-container">
        <!-- 顶部菜单 -->
        <TopHeader headTitle="故障数据分析" :btns="[{value:'返回',to:'/'}]"></TopHeader>
        <!-- /顶部菜单 -->

        <!-- 左侧菜单面板 -->
        <section class="ui-left-panel ui-main-panel">

            <div class="ui-item-panel ui-autoheight-panel">
                <header class="ui-panel-item-title">
                    选择车型
                </header>
                <div class="ui-panel-item-content">
                    <el-row>
                        <el-col v-for="(carType,index) in carTypeList" :key="carType.code" :span="12">
                            <div class="ui-cartype-container" :class="{active:carType.checked}" @click="checkCarType(index)">
                                <div class="ui-car-img">
                                    <img :src="carType.imgURL" alt="">
                                </div>
                                <div class="ui-car-name">{{carType.name}}</div>
                            </div>
                        </el-col>
                    </el-row>
<!--                    <div class="ui-cartype-footer">
                        <el-pagination
                                layout="prev, pager, next"
                                :total="50">
                        </el-pagination>
                    </div>-->
                </div>
            </div>
            <div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    <el-button class="ui-def-btn" :class="{active:0 == tabBtnIndexChecked}" @click="tabBtnIndexChecked = 0">车型信息</el-button>
                    <el-button class="ui-def-btn" :class="{active:1 == tabBtnIndexChecked}" @click="tabBtnIndexChecked = 1" style="float: right;">故障分析报告</el-button>
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <div class="ui-tab-content" v-show="tabBtnIndexChecked === 0">
                        <div class="ui-carlist-container">
                            <el-row>
                                <el-col :span="12">
                                    <img :src="carTypeChecked.imgURL" alt="">
                                </el-col>
                                <el-col :span="12" style="text-align: center;">
                                    <div class="ui-car-tag">{{carTypeChecked.name}}</div>
                                </el-col>
                            </el-row>
                            <table class="ui-carlist-tab">
                                <tbody>
                                <tr>
                                    <td style="color: #47A4FF;">车型运行总数：{{carTypeInfo.count}}</td>
                                </tr>
                                <tr>
                                    <td style="color: #FFAA39;">
                                        能耗类型：{{carTypeInfo.fuelType}}
                                        <!--                                    <span v-if="batteryData.type==1">锂离子电池</span>
                                                                            <span v-else-if="batteryData.type==2">镍氢电池</span>
                                                                            <span v-else-if="batteryData.type==3">燃料电池</span>
                                                                            <span v-else-if="batteryData.type==4">铅酸电池</span>-->
                                    </td>
                                </tr>
                                <tr>
                                    <td >
                                        最高车速：{{carTypeInfo.maxSpeed}}
                                    </td>
                                </tr>
                                <tr>
                                    <td>驱动电机布局：{{carTypeInfo.motorPosition}}</td>
                                </tr>
                                <tr>
                                    <td>纯电续航里程：{{carTypeInfo.electriRange}}</td>
                                </tr>
                                <tr>
                                    <td>燃油指标 ：{{carTypeInfo.fuelNum}}</td>
                                </tr>
                                <tr>
                                    <td>储能装置类型 ：{{carTypeInfo.storageType}}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="ui-tab-content" v-show="tabBtnIndexChecked === 1">
                        <div class="ui-carlist-container">
                            <table class="ui-carlist-tab">
                                <tbody>
                                <tr>
                                    <td> <span style="color: #47A4FF;">{{statisticsData.month}}月份</span>故障报警数最多</td>
                                </tr>
                                <tr>
                                    <td>
                                       <span style="color: #FFAA39;">{{statisticsData.province}}</span>故障报警数最多
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span style="color: red;">{{statisticsData.subsystem}}</span>在所有报警分类中占比最高
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span style="color: yellow;">{{statisticsData.type}}</span>为故障报警数最多的子系统
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>

        </section>
        <!-- /左侧菜单面板 -->

        <!--中间栏面板 -->
        <section class="ui-center-panel ui-main-panel">
            <div class="ui-item-panel ui-autoheight-panel">
                <header class="ui-panel-item-title">
                    <el-row>
                        <el-col :span="4">
                            选择里程
                        </el-col>
                        <el-col :span="20">
                            <div class="ui-btn-container">
                                <el-button v-for="(btnObj,index) in btns" class="ui-def-btn" :key="btnObj.start" :class="{active:index == btnIndexChecked}" @click="btnChange(index)">{{btnObj.name}}</el-button>
                            </div>
                        </el-col>
                    </el-row>
                </header>
                <div class="ui-panel-item-content">
                    <div class="ui-select-mileage">
                        <el-row>
                            <el-col :span="12" style="padding: 15px">
                                <div style="width: 100%;height:400px;margin: auto;" id="J_carType" ref="J_carType">
                                </div>

                            </el-col>
                            <el-col :span="12" style="padding: 15px">
                                <BarList :dataList="malfunctionTop10ByMileage"></BarList>

                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="12">
                                <div class="ui-scription-footer"><i class="el-icon-warning" style="color: #FFA52D;margin-right: 10px;"></i>故障报警分类占比</div>
                            </el-col>
                            <el-col :span="12">
                                <div class="ui-scription-footer"><i class="el-icon-warning" style="color: #FFA52D;margin-right: 10px;"></i>子系统故障数 Top10</div>
                            </el-col>
                        </el-row>

                    </div>

                </div>
            </div>
            <div class="ui-center-top">
                <div class="ui-item-panel" >
                    <header class="ui-panel-item-title">
                        各级故障占比
                        <span class="ui-subtitle">
                            <i class="ui-dot"></i>
                            一级报警
                        </span>
                        <span class="ui-subtitle">
                            <i class="ui-dot" style="background-color: #F59C06;"></i>
                            二级报警
                        </span>
                        <span class="ui-subtitle">
                            <i class="ui-dot" style="background-color: #FF754F;"></i>
                            三级报警
                        </span>
                    </header>
                    <div class="ui-panel-item-content min-font-style">
                        <BarStack mainColor="#5e3536" :lineColor="['#59D5FB','#FFA82F','#FF581D']" :driveData="alertByMileageData"></BarStack>
                        <div style="text-align: center;padding-top: 15px;">行驶里程（KM)</div>
                    </div>
                </div>
                <div class="ui-item-panel">
                    <header class="ui-panel-item-title">
                        平均故障数随里程变化情况
                    </header>
                    <div class="ui-panel-item-content min-font-style">
                        <FullLine mainColor="#5e3536" :lineColor="['#33C1A0','#38B8BF']" :driveData="avgAlertByMileageData"></FullLine>
                        <div style="text-align: center;padding-top: 15px;">行驶里程（KM)</div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /中间栏面板 -->

        <!-- 右侧菜单面板 -->
        <section class="ui-right-panel ui-main-panel">
            <div class="ui-item-panel ui-autoheight-panel">
                <header class="ui-panel-item-title">
                    <el-row>
                        <el-col :span="12">
                            各个省平均故障数
                        </el-col>
                    </el-row>
                </header>
                <div class="ui-panel-item-content">
                    <BarList :dataList="malfunctionTop11"></BarList>
                </div>
            </div>
            <div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    平均故障数月度分布情况
                    <div class="ui-datav-select">
                        <el-select v-model="monthValue" placeholder="请选择">
                            <el-option
                                    v-for="item in monthOptions"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <!--<Bar mainColor="#FF8805" :lineColor="['#E29D14','#EDCB49']"></Bar>-->
                    <Bar mainColor="#FA594D" :lineColor="['#13AD6C','#62D46C']" :driveData="avgAlertByMonthData"></Bar>
                    <div style="text-align: center;padding-top: 15px;">月份</div>
                </div>
            </div>
        </section>
        <!-- /右侧菜单面板 -->


        <!-- 背景地图 -->
        <!--<div class="map-container" id="map-container"></div>-->
        <!-- /背景地图 -->
    </div>
</template>

<script>
    import echarts from 'echarts';
    import CarList from "@/components/carData/CarList.vue";
    import TopHeader from "@/views/TopHeader.vue";
    import DriveLine from "@/components/dlCharts/DriveLine.vue";
    import FullLine from "@/components/dlCharts/FullLine.vue";
    import Bar from "@/components/dlCharts/Bar.vue";
    import BarList from "@/components/dlCharts/BarList.vue";
    import BarStack from "@/components/dlCharts/BarStack.vue";
    import carTypeImgMap from '@/map/carTypeImgMap';
    import {
        avgAlertByMileage,
        carTypes,
        avgAlertByProvince,
        alertTypeTop,
        subsvstemAlertTypeTop,
        avgAlertByMonth,
        statistics,
        alertByMileage
    } from "@/api/malfunction";
    import {
        getBattery,
        getCarTypes
    } from "@/api/powerData";


    //颜色集合
    let colorMap = {
        "0":"rgb(255, 96, 95)",
        "1":"rgb(255, 221, 80)",
        "2":"rgb(91, 167, 255)",
        "3":"rgb(146, 218, 255)",
        "4":"rgb(146, 218, 255)",
        "5":"rgb(146, 218, 255)"
    }


    export default {
        name: "malfunction",
        data() {
            return {
                //车型故障分析数据
                statisticsData:{},
                //默认选中的tab
                tabBtnIndexChecked:0,
                timeDisplay: "",
                //平均故障数月度分布 下拉框
                // 最近12个月  2017年  2016年 2015年 2014年
                monthOptions:[{
                    value: "recently12",//最近12个月
                    type:"recently",
                    timeLimit:[Date.now() - 86400000 * 365, Date.now()],
                    label: '最近12个月'
                }, {
                    value: "2017",//2017
                    type:"year",
                    timeLimit:[1483200000000, 1483200000000 + 86400000 * 365],
                    label: '2017年'
                }, {
                    value: "2016",//2016
                    type:"year",
                    timeLimit:[1451577600000, 1451577600000 + 86400000 * 365],
                    label: '2016年'
                }, {
                    value: "2015",//2015
                    type:"year",
                    timeLimit:[1420041600000, 1420041600000 + 86400000 * 365],
                    label: '2015年'
                }, {
                    value: "2014",//2014
                    type:"year",
                    timeLimit:[1388505600000, 1388505600000 + 86400000 * 365],
                    label: '2014年'
                }],
                //月度数值
                monthValue:"recently12",
                //时间段选择按钮
                btns: [
                    {
                        name:"<1万公里",
                        start:0,
                        end:9999
                    },
                    {
                        name:"1-3万公里",
                        start:10000,
                        end:29999
                    },
                    {
                        name:"3-5万公里",
                        start:30000,
                        end:49999
                    },
                    {
                        name:"5-10万公里",
                        start:50000,
                        end:99999
                    },
                    {
                        name:"10-15万公里",
                        start:100000,
                        end:149999
                    }
                ],
                //车型列表
                carTypeList:[],
                //选中时间段按钮索引
                btnIndexChecked:0,
                //车型code
                code:"CT00005",
                //按月份统计的平均报警数
                avgAlertByMonthData:{},
                //平均故障数随里程变化情况
                avgAlertByMileageData:{},
                //各级故障占比
                alertByMileageData:{},
                //电池基础数据
                batteryData:{},
                //当前选中的车型
                carTypeChecked:{},
                //当前选中的车型的详细数据
                carTypeInfo:{},
                // map: "",
                vin: "",  //选中的车辆的vin
                //机构车辆数TOP 6
                carTop6: [],
                //各省平均故障数 TOP11
                malfunctionTop11: [],
                // 按里程数获取报警类型数TOP 10
                malfunctionTop10ByMileage: [],
                //故障报警分类占比 饼图对象
                alertTypeTopPie: "",
                //当前的行政区域聚合
                distCluster: "",
                //车辆总数
                carCount: 0,
                //当前在线总数
                onlineCount: 0,
                mapTimer: ""
            }
        },
        mounted(){
            this.getCarTypes();

            this.initCarTypeCharts();
        },
        methods: {
            /**
             *
             *  获取指定时间段各省份平均报警topN
             *
             * */
            avgAlertByMonth() {

                //获得对应的月份数据
                let monthData = this.monthOptions.find((element)=>{
                    return element.value === this.monthValue;
                });

                //获取开始充电时刻分布数据接口
                avgAlertByMonth({
                    "vehicleType": this.carTypeChecked.code,
                    "start": monthData.timeLimit[0],
                    "end": monthData.timeLimit[1]
                }).then((res) => {
                    //格式化数据
                    this.avgAlertByMonthData = res.results;
                });
            },
            /**
             *
             *  获取指定时间段各省份平均报警topN
             *
             * */
            avgAlertByProvince() {

                //获得对应的月份数据
                let monthData = this.monthOptions.find((element)=>{
                    return element.value === this.monthValue;
                });

                //获取开始充电时刻分布数据接口
                avgAlertByProvince({
                    "vehicleType": this.carTypeChecked.code,
                    "start": monthData.timeLimit[0],
                    "end": monthData.timeLimit[1],
                    "top": 11
                }).then((res) => {
                    //如果返回的不是一个空数组
                    if(res.results.data.length > 0){
                        this.malfunctionTop11 = this.topFormatData(res.results.data);
                    }else{
                        this.malfunctionTop11 = [];
                    }
                });
            },
            /**
             *
             *  按里程数获取报警类型数TOPN
             *
             * */
            alertTypeTop() {

                //选中的里程按钮
                let btnCheckData = this.btns[this.btnIndexChecked];

                //发送请求
                alertTypeTop({
                    "vehicleType": this.carTypeChecked.code,
                    "start": btnCheckData.start,
                    "end": btnCheckData.end,
                    "top": 6
                }).then((res) => {
                    //格式化数据
                    // this.malfunctionTop10ByMileage = this.topFormatData(res.results.data);
                    this.alertTypeTopPie.setOption({
                        series:[{
                            data: res.results.data
                        }]
                    });
                });

            },
            /**
             *
             *  按里程数获取报警类型数TOPN
             *
             * */
            subsvstemAlertTypeTop() {
                //选中的里程按钮
                let btnCheckData = this.btns[this.btnIndexChecked];

                subsvstemAlertTypeTop({
                    "vehicleType": this.carTypeChecked.code,
                    "start": btnCheckData.start,
                    "end": btnCheckData.end,
                    "top": 10
                }).then((res) => {

                    //如果返回的不是一个空数组
                    if(res.results.data.length > 0){
                        this.malfunctionTop10ByMileage = this.topFormatData(res.results.data);
                    }else{
                        this.malfunctionTop10ByMileage = [];
                    }
                });

            },
            initCarTypeCharts() {
                this.alertTypeTopPie = echarts.init(this.$refs["J_carType"]);
                let option = {
                    tooltip : {
                        trigger: 'item',
                        formatter: "{c}<br>{b} ：({d}%)"
                    },
                    grid:{
                        x:100
                    },
                    series : [
                        {
                            type: 'pie',
                            color: ['#FFA52D','#1680C0','#3dbbff','#ECDF0E','#536CF7','#76EDBD'],
                            center: ['50%', '50%'],
                            selectedMode: 'single',
                            /*data:[
                                {value:335, name:'直接访问'},
                                {value:310, name:'邮件营销'},
                                {value:300, name:'邮件营销2'},
                                {value:274, name:'联盟广告'},
                                {value:235, name:'视频广告'},
                                {value:400, name:'搜索引擎'}
                            ],*/
                            itemStyle: {
                                emphasis: {
                                    shadowBlur: 10,
                                    shadowOffsetX: 0,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                            },
                            roseType: 'radius',
                            animationType: 'scale',
                            animationEasing: 'elasticOut'
                        }
                    ]
                };
                this.alertTypeTopPie.setOption(option);
            },
            /**
             *  TOP6 数据的格式化
             *
             *  @param carTop6
             *  @return {Array}  carTop6  格式化之后的数据
             *
             * */
            topFormatData(carsTop) {
                //首先降序排序
                // let carsTop = carsTop.sort(this.compare("value"));

                //设置颜色
                carsTop = this.setColorByIndex(carsTop, colorMap);

                //设置百分比
                carsTop = this.setPercent(carsTop, carsTop[0].value);

                return carsTop;
            },
            compare(property) {
                return function (obj1, obj2) {
                    let value1 = obj1[property];
                    let value2 = obj2[property];
                    return value2 - value1;     // 降序
                }
            },
            /**
             * 设置进度条颜色
             *
             * @param carTop6
             * @param colorMap  颜色集合
             */
            setColorByIndex(carsTop , colorMap) {

                //遍历数据设置颜色
                let newCarsTop = carsTop.map((element,index)=>{

                    //给个默认颜色
                    if (index > 5) {
                        index = 5;
                    }

                    element.color = colorMap[index];
                    return element;
                });

                return newCarsTop;
            },
            /**
             * 设置进度条百分比
             *
             * @param carTop6
             * @param denominator  分母
             *
             */
            setPercent(tops, denominator) {

                //遍历数据设置百分比
                let newTops = tops.map((element) => {
                    element.percent = parseFloat((element.value / denominator * 100).toFixed(1));
                    return element;
                });

                return newTops;
            },
            /**
             * 按钮选中的切换方法
             *
             * @param index   选中按钮的索引
             */
            btnChange(index){
                //当前点击按钮设为选中
                this.btnIndexChecked = index;
            },
            /**
             * 获取搜索基本参数，包含选中车型，起止时间等等
             *
             */
            getBaseParams(){
                //生成时间范围
                let searchTimeRange = this.genTimeRangeParams(this.btnIndexChecked);

                //生成基本的搜索参数
                let baseParams = Object.assign(searchTimeRange,{
                    "vehicleType":this.carTypeChecked.code
                });
                return baseParams;

            },
            /**
             * 按钮选中的切换方法
             *
             * @param index   选中按钮的索引
             */
            genTimeRangeParams(index) {

                //得到时间范围
                let timeLimit = this.btns[index].timeLimit;
                let nowTime = Date.now();

                //起止时间数据
                return {
                    start: nowTime - timeLimit,
                    end: nowTime
                }

            },
            /**
             *
             *  按里程获取车辆报警数比例
             *
             * */
            alertByMileage(){
                //获取基本的搜索参数
                //获取开始充电时刻分布数据接口
                alertByMileage({
                    "vehicleType":this.carTypeChecked.code
                }).then((res) => {
                    this.alertByMileageData = res.results;

                    //处理柱状堆叠图 数据
                    // J_alertCharts
                });
            },
            /**
             *
             *  平均故障数随里程变化情况
             *
             * */
            avgAlertByMileage(){
                //获取开始充电时刻分布数据接口
                avgAlertByMileage({
                    "vehicleType":this.carTypeChecked.code
                }).then((res) => {
                    this.avgAlertByMileageData = res.results;
                });
            },
            /**
             *
             *  平均故障数随里程变化情况
             *
             * */
            carTypes(){
                //获取开始充电时刻分布数据接口
                carTypes({
                    "code":this.carTypeChecked.code
                }).then((res) => {
                    this.carTypeInfo = res.results;
                });
            },
            /**
             *
             *  获取车型列表
             *
             * */
            getCarTypes(){
                //获取车型列表
                getCarTypes().then((res) => {
                    let carTypeList = res.results.map((element, index) => {

                        //默认选中第一个
                        if(index === 0){
                            element.checked = true;
                        }else{
                            element.checked = false;
                        }

                        //加上 imgURL
                        return Object.assign(element, {
                            "imgURL": carTypeImgMap[element.code]
                        })

                    });

                    this.carTypeList  = carTypeList;

                    //TODO 测试数据  用完记得删除
                    let demoData = Object.assign({}, this.carTypeList[0]);
                    demoData.code = "CT00080";

                    //设置基本的搜索参数
                    this.carTypeChecked = demoData;

                    //更新页面数据
                    this.updateCommon();

                });
            },
            /**
             *
             *  获取车型电池基本数据
             *
             * */
            getBattery(){
                //车型基本数据
                let carTypeBaseInfo = this.carTypeChecked;
                //获取车型电池基本数据
                getBattery({
                    code:this.code
                }).then((res) => {
                    this.batteryData = Object.assign(res.results, carTypeBaseInfo);
                });
            },
            /**
             *
             *  获取车型故障分析
             *
             * */
            statistics(){
                //获取车型故障分析
                statistics({
                    vehicleType:this.carTypeChecked.code
                }).then((res) => {
                    this.statisticsData = res.results;
                });
            },
            /**
             *  根据索引选中某一个车型
             *
             * */
            checkCarType(index){
                //老选中元素的索引
                let oldIndex = this.carTypeList.findIndex((element) => {
                    return element.checked == true;
                });
                this.carTypeList[oldIndex].checked = false;
                this.carTypeList[index].checked = true;

                //TODO 测试数据  用完记得删除
                let demoData = Object.assign({}, this.carTypeList[index]);
                demoData.code = "CT00080";

                this.carTypeChecked = demoData;

                //更新页面数据
                this.updateCommon();
            },
            /**
             *  更新页面的主要数据
             *
             * */
            updateCommon(){
                //设置充电基本数据
                this.getBattery();

                //车型数据
                this.carTypes();

                //平均故障数随里程变化情况
                this.avgAlertByMileage();

                //按里程获取车辆报警数比例
                this.alertByMileage();

                //获取指定时间段各省份平均报警topN
                this.avgAlertByProvince();

                //月份统计的平均报警数
                this.avgAlertByMonth();

                //按里程数获取报警类型数占比
                this.alertTypeTop();

                //按里程数获取报警类型数TOPN
                this.subsvstemAlertTypeTop();

                //获取车型故障分析
                this.statistics();

            }
     },
        watch:{
            carTypeChecked: function () {
                this.updateCommon();
            },
            btnIndexChecked: function () {
                console.log("切换里程");
                //按里程数获取报警类型数占比
                this.alertTypeTop();

                //按里程数获取报警类型数TOPN
                this.subsvstemAlertTypeTop();
            },
            /**
             * 监听 月度分布变化
             *
             */
            monthValue: function () {
                //月份统计的平均报警数
                this.avgAlertByMonth();
                //获取指定时间段各省份平均报警topN
                this.avgAlertByProvince();
            }
        },
        components:{CarList,DriveLine,TopHeader,Bar,FullLine,BarList,BarStack}
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    @import "src/styles/mixin.scss";


    .ui-logo{
        margin: 20px 40px;

    }
    dl {
        margin: 0;
        & > dd {
            margin: 0;
        }
    }
    .ui-dot{
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #3a8ee6;
    }



    $lightBlue:#47A4FF;
    $mangoYello:#FFAA39;

   .ui-container{
       display: flex;

       position: relative;
       width: 100%;
       height: 100%;
       min-height: 1040px;

       background: #000000;

       // 关于模块背景色的样式
       @mixin black-style { 
           background: rgba(36,38,50,.73);
       }


       .ui-scription-footer{
           text-align: center;
           font-size: 18px;
       }

       .ui-container-head{
           position: absolute;
           top: 0;
           left: 0;

           z-index: 3;
           
           width: 100%;
           height: 80px;

           background:url("/static/img/head_back.png") no-repeat;

           //@include black-style;

           .ui-head-right{
               height: 80px;
               line-height: 80px;
               vertical-align: middle;
               margin-right: 30px;

               float: right;
           }

           .ui-time{
               font-family: PingFangSC-Regular;
               font-size: 24px;
               color: #FFFFFF;
               letter-spacing: 0;
               margin: 0 35px;
           }
           .ui-change-btn{
               opacity: 0.73;
               background: #242632;
               border: 1px solid #3D3D3E;
               border-radius: 4px;

               font-size: 20px;
               color: #0070FF;
           }
           
       }

       .ui-main-panel{
           display: flex;

           z-index: 2;
           /*width: 440px;*/

           padding: 15px;
           padding-top: 0;

           flex-direction:column-reverse;


           .ui-down-big-panel{
               display: flex;
               .ui-item-panel{
                   margin-right: 15px;

                   &:first-child{
                       flex: 2;
                   }
                   &:last-child{
                       flex:1;
                       margin-right: 0;
                   }
               }
           }

           .ui-top-big-panel{
               display: flex;
               .ui-item-panel{
                   flex: 1;
                   margin-right: 15px;

                   &:last-child{
                       margin-right: 0;
                   }
               }
           }

           .ui-item-panel{
               position: relative;

               margin-top: 15px;

               border: 1px solid #3d3d3e;
               border-radius: 2px;
               @include black-style;

               .ui-panel-item-title{
                   display: block;
                   height: 45px;
                   padding: 10px 15px;
                   /*padding-right: 50px;*/
                   color: #fff;

                   font-size: 22px;
               }
               .ui-panel-item-content{
                   color: #ffffff;

                   padding: 15px;

                   border-radius: 0 2px 2px 2px;
               }
           }

       }

       .ui-left-panel{
           height: calc(100% - 100px);
           width: 20%;
           position: absolute;
           left: 0;
           bottom: 0;
       }
       .ui-center-panel{

           width: 55%;
           height: calc(100% - 100px);
           position: absolute;
           left: 20%;
           bottom: 0;
           padding: 0 0 15px 0;

           .ui-center-top{
               display: flex;

               .ui-item-panel{
                   /*width: calc(50% - 15px);*/
                   width: 50%;
                   flex: 1;
               }

               &>:first-child{
                   margin-right: 15px;
               }
           }

           .ui-drive-info-tab{
               width: 100%;

               td{
                   height: 30px;
                   line-height: 30px;
               }
           }
       }

       .ui-right-panel{
           height: calc(100% - 100px);
           width: 25%;
           position: absolute;
           right: 0;
           bottom: 0;
       }

       .ui-full-panel{
           max-height: 100%;
           overflow: auto;
       }
       .ui-autoheight-panel{
           flex: 1;
       }

       .map-container{
           width: 100%;
           height: 100%;
       }

       .ui-count-title{
           margin-right: 30px;
           margin-left: 50px;
       }
   }

   .ui-subtitle{
       margin-left: 20px;
       font-size: 14px;
   }

    .ui-month-panel{

        @include clearfix;

        .ui-month-col{
            width: 33.333%;
            display: inline-block;
            float: left;

            text-align: center;
        }


    }

    .ui-btn-container{
        text-align: right;
    }

    .ui-def-btn{
        background: none;
        border-radius: 0;
        border-color: #444;
        color: #fff;
        font-size: 16px;
        &.active{
            /*background: linear-gradient(left,red,blue);*/
            background: -webkit-linear-gradient(left, #1b5890 , #475a90); /* Safari 5.1 - 6.0 */
        }
    }

    .ui-driveline-scription{
        padding: 5px 0;
        text-align: center;
        color: #BAB3B3;
        font-size: 14px;
    }

    .ui-carlist-tab{
        width: 100%;
        text-align: center;

        &>thead td{
            height: 30px;
            line-height: 30px;
            font-size: 18px;

            &:nth-child(1){
                color: #0C7FFF;
            }
            &:nth-child(2){
                color: #FFAA39;
            }
            &:nth-child(3){
                color: #36A666;
            }
        }

        &>tbody td{
            height: 30px;
            line-height: 30px;
            font-size: 16px;
            color: #FFFFFF;
            text-align: left;
        }
    }




    .ui-car-tag{
        display: inline-block;
        padding: 5px 15px;
        background: -webkit-linear-gradient(left, #366EB6, #414CA8);
        border-radius: 100px;
        margin-top: 20px;
    }
    .ui-cartype-container{
        height: 98px;
        padding-top: 10px;
        margin: 5px 0;

        cursor: pointer;

        &.active{
            background: url(/static/img/powerData/car_checked.png) no-repeat 100% 100%;
            background-position: center;
            background-size: contain;
        }
    }
    .ui-car-img{
        min-height: 60px;

        img{
            display: block;
            margin: auto;
        }
    }
    .ui-car-name{
        margin-top: 5px;

        text-align: center;
        font-size: 14px;
    }
</style>

<style rel="stylesheet/scss" lang="scss">
    .ui-cartype-footer{
        & *{
            background: none!important;
            color: #414CA8;
        }

        .el-pagination{
            text-align: center;
        }
    }

    .ui-datav-select{
        display: inline-block;
        float: right;
        width: 120px;

        .el-input__inner{
            background: none;
            border-color: #444;
            color: #fff;
            border-radius: 0;
        }
    }

    .el-select-dropdown{
        border: 1px solid #444;
        border-radius: 0;
        background-color: #1a1c24;
        color: #fff;

        .el-select-dropdown__item{
            &.hover,&:hover{
                background-color: #373738;
            }
        }
    }
    .el-popper[x-placement^=bottom] .popper__arrow::after{
        top: 0px;
        margin-left: -6px;
        border-bottom-color: #444;
    }
</style>