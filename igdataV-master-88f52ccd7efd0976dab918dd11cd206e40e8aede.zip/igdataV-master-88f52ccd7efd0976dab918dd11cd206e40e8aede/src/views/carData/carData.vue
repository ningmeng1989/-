<template>
    <div class="ui-container">
        <!-- 顶部菜单 -->
        <TopHeader headTitle="单车运营数据分析" :btns="[{value:'返回',to:'/'}]"></TopHeader>
        <!-- /顶部菜单 -->

        <!-- 左侧菜单面板 -->
        <section class="ui-left-panel ui-main-panel">
            <div class="ui-item-panel ui-autoheight-panel">
                <header class="ui-panel-item-title">
                    车辆列表
                    <el-button type="text" style="float: right;" @click="showFullHeight()">
                        {{!isFullHeight?"显示全部":"收起"}}
                    </el-button>
                </header>
                <div class="ui-panel-item-content">
                    <CarList @clickTr="carChecked" :oneOrFull="!isFullHeight"></CarList>
                </div>
            </div>
            <div class="ui-item-panel" v-show="!isFullHeight">
                <header class="ui-panel-item-title">
                    基本信息
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <CarInfo :key="vin" :vin="vin" @infoReady="setCarInfo"></CarInfo>
                </div>
            </div>
            <div class="ui-item-panel" v-show="!isFullHeight">
                <header class="ui-panel-item-title">
                    <el-button class="ui-def-btn" :class="{active:0 == tabBtnIndexChecked}" @click="tabBtnIndexChecked = 0">行驶行为分析</el-button>
                    <el-button class="ui-def-btn" :class="{active:1 == tabBtnIndexChecked}" @click="tabBtnIndexChecked = 1" style="float: right;">车辆异常信息</el-button>
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <div class="ui-tab-content" v-show="tabBtnIndexChecked === 0">
                        <table class="ui-drive-data-tab">
                            <tbody>
                            <tr>
                                <td>行程特点：
                                    <span style="color: #0C7FFF;">
                                        <!--1、中短，2、中长，3、长途-->
                                        <span v-if="driveInfo.travelTypeData == 1">中短</span><span v-if="driveInfo.travelTypeData == 2">中长</span><span v-if="driveInfo.travelTypeData == 3">长</span>途行驶为主
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td>推断家庭位置：<span style="color: #F8BD20;">{{dayStopTimeMaxData.position}}</span></td>
                            </tr>
                            <tr>
                                <td>最常充电位置：<span style="color: #009461;">{{mostChargingAddrData.addr}}</span></td>
                            </tr>
                            <tr>
                                <td>出行半径：<span style="color: #F8BD20;">{{driveInfo.travelRadData}}公里</span></td>
                            </tr>
                            <tr>
                                <td>推断公司位置：<span style="color: #0C7FFF;">{{nightStopTimeMaxData.position}}</span></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="ui-tab-content" v-show="tabBtnIndexChecked === 1">
                        <div v-if="hasAbnormity">
                            <div>
                                <img src="/static/img/carData/car_exception.png" alt="" style="display: block;margin: auto;">
                            </div>
                            近5000公里行程中，百公里电耗上升过快
                            与对应车型均值差异明显
                        </div>
                        <div v-else style="text-align: center">
                            暂无异常信息
                        </div>

                    </div>

                </div>
            </div>
        </section>
        <!-- /左侧菜单面板 -->

        <!--中间栏面板 -->
        <section class="ui-center-panel ui-main-panel">
            <div class="ui-item-panel">
                <header class="ui-panel-item-title" style="text-align: left;">
                    综合行驶信息
                </header>
                <div class="ui-panel-item-content">
                    <el-row>
                        <el-col :span="6" style="text-align: center;">
                            <div>
                                <img :src="carInfo.carTypeImg" alt="">
                            </div>
                            <el-button type="primary" round>{{carInfo.plate}}</el-button>
                        </el-col>
                        <el-col :span="18">
                            <table class="ui-drive-info-tab">
                                <tbody>
                                <tr>
                                    <td>车型：<span style="color: rgb(12, 127, 255);">{{carInfo.type}}</span></td>
                                    <td>
                                        驾驶者性别：
                                        <span v-if="carInfo.sex">女</span>
                                        <span>男</span>
                                    </td>
                                    <td>驾驶者年龄：{{carInfo.age}}</td>
                                </tr>
                                <tr>
                                    <td>行驶总里程：{{synthesizeDriveInfo.totalMile}}公里</td>
                                    <td>平均车速：{{synthesizeDriveInfo.speedAVG}}公里/小时</td>
                                    <td>平均油耗：{{synthesizeDriveInfo.fuelConsumption}}L/百公里</td>
                                </tr>
                                <tr>
                                    <td>行驶总时长：{{synthesizeDriveInfo.totalTime}}小时</td>
                                    <td>最高车速：{{synthesizeDriveInfo.maxSpeed}}公里/小时</td>
                                </tr>
                                </tbody>
                            </table>
                        </el-col>
                    </el-row>

                </div>
            </div>
        </section>
        <!-- /中间栏面板 -->

        <!-- 右侧菜单面板 -->
        <section class="ui-right-panel ui-main-panel">
            <div class="ui-item-panel ui-full-panel">
                <header class="ui-panel-item-title" style="text-align: left;">
                    日常行驶数据
                    <div class="ui-datav-select">
                        <el-select v-model="recentlyValue" placeholder="请选择" @change="updateRightBar">
                            <el-option
                                    v-for="item in recentlyOptions"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                </header>
                <div class="ui-panel-item-content">
                    <div class="ui-month-panel min-font-style">
                        <DriveLine title="在线时长" :driveData="onlineData" mainColor="#3FB04C" style="margin-top: 0;" :lineColor="['#7AFE8A','#0F8E6B']"></DriveLine>
                        <DriveLine title="报警数" :driveData="alarmCountData" mainColor="#FA594D" :lineColor="['#FF99BA','#FA2C60 ']"></DriveLine>
                        <DriveLine title="能耗" :driveData="energyConsumptionData" mainColor="#FF8805" :lineColor="['#FF9500','#FF9500']"></DriveLine>
                        <DriveLine title="行驶里程" :driveData="travelMileageData" mainColor="#4CB6FF" :lineColor="['#5AB2FF','#5442FF']"></DriveLine>
                    </div>
                </div>
            </div>
        </section>
        <!-- /右侧菜单面板 -->


        <!-- 背景地图 -->
        <div class="map-container" id="map-container"></div>
        <!-- /背景地图 -->
    </div>
</template>

<script>
    import axios from 'axios'

    import {
        getTravelType,
        getMostChargingAddr,
        dayNightStopTimeMax,
        getTravelRad,
        onlineSeconds,
        alarmCount,
        getTravelQuery,
        energyConsumption,
        energyAbnormity,
        topNStopTime,
        travelMileage
    } from "@/api/carData";

    import carTypeImgMap from '@/map/carTypeImgMap';

    import CarList from "@/components/carData/CarList.vue";
    import CarInfo from "@/components/carData/CarInfo.vue";
    import TopHeader from "@/views/TopHeader.vue"
    import DriveLine from "@/components/dlCharts/DriveLine.vue";
    import dateUtils from '@/utils/dateUtils';



    //颜色集合
    let colorMap = {
        "0":"rgb(255, 96, 95)",
        "1":"rgb(255, 221, 80)",
        "2":"rgb(91, 167, 255)",
        "3":"rgb(146, 218, 255)",
        "4":"rgb(146, 218, 255)",
        "5":"rgb(146, 218, 255)"
    };

    //报警颜色集合
    let alertColorMap = {
        "0":"#0FA3FF",
        "1":"#FF5350",
        "2":"#3CE18B",
        "3":"#8e71c7",
        "4":"#FF7300",
        "5":"#675DDE"
    };


    //地图车辆图标颜色集合
    let carColorMap = {
        "1":"47,139,255",
        "2":"192,182,0",
        "3":"0,170,95"
    };

    //缓存地图
    let map;
    let mapTimer;

    let districtCluster;



    export default {
        name: "add-cars",
        data() {
            return {
                map: "",
                tabBtnIndexChecked: 0,
                vin: "",  //选中的车辆的vin
                //车辆列表高度是否显示一屏
                isFullHeight: false,

                // 最近一周，最近一月，最近半年，最近一年
                recentlyOptions:[{
                    value: "week",//最近一周
                    type:"week",
                    timeLimit: 86400000 * 7,
                    label: '最近一周'
                }, {
                    value: "moon",//最近一月
                    type:"moon",
                    timeLimit: 86400000 * 30,
                    label: '最近一月'
                }, {
                    value: "halfYear",//最近半年
                    type:"halfYear",
                    timeLimit: 86400000 * 182.5,
                    label: '最近半年'
                }, {
                    value: "year",//最近一年
                    type:"year",
                    timeLimit: 86400000 * 365,
                    label: '最近一年'
                }],
                //月度数值
                recentlyValue: "moon",
                mapTimer: "",
                //在线时长数据
                onlineData: [],
                //报警数据
                alarmCountData: [],
                //能耗数据
                energyConsumptionData: [],
                //行驶里程数据
                travelMileageData: [],
                //综合行驶信息
                synthesizeDriveInfo: {},
                //车辆是否有异常信息
                hasAbnormity: false,
                //车辆信息
                carInfo: {},
                //车辆行驶行为分析数据
                driveInfo: {},
                //日间停车数据
                dayStopTimeMaxData: {},
                //夜间停车数据
                nightStopTimeMaxData: {},
                //最长充电数据
                mostChargingAddrData: {}
            }
        },
        methods: {
            /**
             *
             *  往地图上添加 推断 家庭、公司地点， 常用充电地点图标
             *
             * */
            addHomeCompanyCharge(home,company,charge){
                //数据,包括推断 家庭、公司、地址，最常充电地点
                let data = [];
                let content = '<div class="marker-route"><img src="/static/img/carData/marker.png" alt=""></div>';

                //遍历生成多个点标注
                let markers = data.map((element) => {
                    return new AMap.Marker({
                        content: content,  // 自定义点标记覆盖物内容
                        position: [element.lng, element.lat], // 基点位置
                        offset: new AMap.Pixel(-17, -42) // 相对于基点的偏移位置
                    })
                });

                map.add(markers);

            },
            /**
             *
             *  往地图上添加 图标
             *
             * */
            addMarkerTopN(data){
                //遍历生成多个点标注
                let markers = data.map((element) => {

                    //marker 配置
                    let markerConfig = {
                        content: `<div class="marker-route"><img src="${element.imgURL}" alt=""></div>`,  // 自定义点标记覆盖物内容
                        position: element.lngLat, // 基点位置
                        offset: new AMap.Pixel(-17, -42) // 相对于基点的偏移位置
                    };

                    //如果显示label
                    if (element.showLabel) {
                        markerConfig.label = {
                            offset: new AMap.Pixel(-95, -120), //修改label相对于marker的位置
                            content: this.genLabelContent(element)
                        }
                    }

                    return new AMap.Marker(markerConfig)
                });

                map.add(markers);

            },
            /**
             *  生成 图标 label 的内容
             *
             *  @param  markerData  图标数据
             *
             *  @return  labelContent  最终生成的 content
             *
             * */
            genLabelContent(markerData){
                //遍历生成多个点标注
                let labelContent = `<div class="ui-marker-window">
                                          <div class="ui-marker-title" style="color: ${markerData.baseColor}">${markerData.title}</div>
                                          <div class="ui-marker-description">${markerData.description}</div>
                                          <div class="ui-marker-info">累计停留 <span  style="color: ${markerData.baseColor}">${markerData.parkTimeCount}</span> 小时  充电 <span  style="color: ${markerData.baseColor}">${markerData.chargeCount}</span>次</div>
                                     </div>`;

                return labelContent;
            },
            /**
             *
             *  停车位置 坐标数据查询查询接口
             *
             * */
            updateMarkerData(){

                //根据和产品沟通，单车页面数据，默认以半年
                let end = Date.now();
                let start = end - 182.5 * 86400000;

                //获取车辆异常信息
                let params = {
                    vin: this.vin,
                    //TODO 测试数据
                    vin: "L6T7944Z3HN400820",
                    start: start,
                    end: end,
                    amount: 10
                };

                //根据车牌号搜索车辆
                axios.all([
                    topNStopTime({...params, timeBucket: 1, amount: 1}),
                    topNStopTime({...params, timeBucket: 2, amount: 1}),
                    topNStopTime({...params, timeBucket: 3, amount: 10}),
                    getMostChargingAddr(params)
                ])
                .then(axios.spread((nightRes, dayRes, topTimeRes,mostChargingAddrData) => {
                    //整合参数
                    let dataList = [...nightRes.results.data, ...dayRes.results.data, ...topTimeRes.results.data];
                    //格式化数据
                    dataList = this.formatMarkerData(dataList,mostChargingAddrData.results.data);

                    //添加 marker 点
                    this.addMarkerTopN(dataList);

                    //自动缩放地图视角
                    map.setFitView();

                }))
                .catch(function (error) {
                     console.log(error);
                });
            },
            /**
             *
             * 设置车辆信息
             *
             * */
            setCarInfo(carInfo){

                //车型图片
                carInfo.carTypeImg = carTypeImgMap[carInfo.typeCode];

                //设置车辆信息
                this.carInfo = carInfo;
            },
            /**
             *
             * 车辆列表显示一屏
             *
             * */
            showFullHeight(){
                this.isFullHeight = !this.isFullHeight;
            },
            /**
             *
             * 更新右侧面的数据
             *
             * */
            updateRightBar(){
                //得到参数
                let params = this.genRightBarTimeRangeParams();

                //根据车牌号搜索车辆
                axios.all([onlineSeconds(params), alarmCount(params), energyConsumption(params), travelMileage(params)])
                    .then(axios.spread((onlineRes, alarmCountRes, energyConsumptionRes, travelMileageRes) => {
                        //在线时长数据
                        this.onlineData = this.formatLineData(onlineRes.results.data,"onlineSeconds");
                        //报警数据
                        this.alarmCountData = this.formatLineData(alarmCountRes.results.data,"alarmCount");
                        //能耗数据
                        //TODO:能耗要根据车型来定  ：燃油还是电动车
                        // this.energyConsumptionData = this.formatLineData(energyConsumptionRes.results.data,"fuelConsumption");
                        //行驶里程数据
                        this.travelMileageData = this.formatLineData(travelMileageRes.results.data,"travelMileage");


                    }))
                    .catch(function (error) {
                        console.log(error);
                    });
            },
            /**
             *
             * 格式化数据，将数据从 数组，转换为 DriveLine(封装 echarts)组件需要的数据格式
             *
             * @param  {Array} dataList  数据集合
             * @param  {String} valKey  值的key ，为了提升通用性而增加了这个参数
             *
             * */
            formatLineData(dataList,valKey){
                //X轴名称
                let category = [];
                //数据
                let chartsData = [];

                dataList.forEach(function(element) {
                    category.push(new Date(element.time).format("M-dd"));
                    chartsData.push(element[valKey]);
                });

                return {
                    category:category,
                    data:chartsData
                }

            },
            /**
             *
             * 格式化数据，将数据从 数组，转换为 添加marker到地图上 需要的数据格式
             *
             * @param  {Array} data  推断家庭位置
             *
             * @return  {Array} data  值的key ，为了提升通用性而增加了这个参数
             *
             * */
            formatMarkerData(data,mostChargingAddrData){

                //遍历处理数据
                data = data.map((element,index)=>{
                    //第一个位置为家
                    if(index === 0){
                        return {
                            title: element.position,
                            description:"夜间长时间停留，推断家庭住址",
                            type:"home",//家庭住址
                            showLabel:true, //默认是否显示 label
                            baseColor:"#F8BD20", //基础颜色
                            imgURL:"/static/img/carData/home.png",//家庭图片
                            lngLat: [element.lng, element.lat],
                            parkTimeCount:Math.round(element.totalTime / 3600000),//累计停留时间 小时
                            chargeCount:element.stopCount//累计充电次数
                        }
                    }
                    //第二个位置为公司
                    else if(index === 1){
                        return {
                            title: element.position,
                            description:"日间长时间停留，推断公司位置",
                            type:"company",//公司位置
                            baseColor:"#009461", //基础颜色
                            showLabel:true, //默认是否显示 label
                            imgURL:"/static/img/carData/company.png",//公司图片
                            lngLat: [element.lng, element.lat],
                            parkTimeCount:Math.round(element.totalTime / 3600000),//累计停留时间 小时
                            chargeCount:element.stopCount//累计充电次数
                        }
                    }
                    //其他常去位置
                    else{
                        return {
                            title: element.position,
                            description:"长时间停留",
                            type:"most",//常去位置
                            showLabel:false, //默认是否显示 label
                            baseColor:"#008BFF", //基础颜色
                            imgURL:"/static/img/carData/marker.png",//普通点标记图片
                            lngLat: [element.lng, element.lat],
                            parkTimeCount:Math.round(element.totalTime / 3600000),//累计停留时间 小时
                            chargeCount:element.stopCount//累计充电次数
                        }
                    }
                });

                //处理最常充电位置
                data = this.setMostChargingAddr(data,mostChargingAddrData);

                return data.reverse();

            },
            /**
             *
             *  处理最常充电位置 的逻辑，最常充电位置一般和 常停留位置有关联
             *
             * @param  {Array} data  所有的 marker 数据
             *
             * @return  {Array} mostChargingAddrData  常用充电位置信息
             *
             * */
            setMostChargingAddr(data, mostChargingAddrData) {
                //处理最常充电位置
                //120.2018, 30.2143
                //找到最常充电位置的索引
                let mostAddrIndex = data.findIndex(function(element) {
                    return mostChargingAddrData.lng === element.lngLat[0] && mostChargingAddrData.lat === element.lngLat[1];
                });

                //如果最常充电位置重复
                if(mostAddrIndex !== -1){
                    //得到重复 marker 的类型
                    let markerType = data[mostAddrIndex].type;

                    //推断家庭位置
                    if(markerType === "home"){
                        //修改一下图片地址
                        data[mostAddrIndex].imgURL = "/static/img/carData/home_charge.png";
                    }
                    //推断公司位置
                    else if(markerType === "company"){
                        //修改一下图片地址
                        data[mostAddrIndex].imgURL = "/static/img/carData/company_charge.png";

                    }
                    //常去位置
                    else if(markerType === "most"){
                        //修改一下图片地址
                        data[mostAddrIndex].imgURL = "/static/img/carData/most_charge.png";

                    }


                }
                //如果最常充电位置没有重复
                else{

                    data.push({
                        title: mostChargingAddrData.addr,
                        description: "最常充电位置",
                        type: "mostCharge",//最常充电位置
                        baseColor: "#FF5858", //基础颜色
                        showLabel: true, //默认是否显示 label
                        imgURL: "/static/img/carData/charge.png",//公司图片
                        lngLat: [mostChargingAddrData.lng, mostChargingAddrData.lat],
                        parkTimeCount: Math.round(mostChargingAddrData.totalTime / 3600000),//累计停留时间 小时
                        chargeCount: mostChargingAddrData.count//累计充电次数
                    });
                }


                return data;
            },
            /**
             *
             * 行驶行为分析
             *
             * */
            driveTraitInfo(){
                //根据和产品沟通，单车页面数据，默认以半年
                let end = Date.now();
                let start = end - 182.5 * 86400000;

                //整合参数
                let params = {
                    vin: this.vin,
                    //TODO 测试数据
                    vin: "L6T79F4Z1JN400056",
                    start: start,
                    end: end
                };

                //日、夜 间最长充电
                let dayParams = Object.assign({},params);
                dayParams.timeBucket = 1;

                let nightParams = Object.assign({},params);
                nightParams.timeBucket = 2;

                //根据车牌号搜索车辆
                axios.all([getTravelType(params), getMostChargingAddr(params),dayNightStopTimeMax(dayParams),dayNightStopTimeMax(nightParams),getTravelRad(params)])
                    .then(axios.spread((travelTypeData, mostChargingAddrData,dayStopTimeMaxData,nightStopTimeMaxData,travelRadData)=>{

                        //驾驶行为信息
                        let driveInfo = {};

                        // 行程特点  1、中短，2、中长，3、长途
                        driveInfo.travelTypeData = travelTypeData.results.data;

                        //常用充电位置
                        this.mostChargingAddrData = mostChargingAddrData.results;

                        //推断家庭位置
                        this.dayStopTimeMaxData = dayStopTimeMaxData.results;

                        //推断公司位置
                        this.nightStopTimeMaxData = nightStopTimeMaxData.results;

                        //出行半径
                        driveInfo.travelRadData = travelRadData.results.data;

                        this.driveInfo = driveInfo;
                    }))
                    .catch(function (error) {
                        console.log(error);
                    });
            },
            /**
             *  车辆行驶总时长、总里程、总油耗、最大速度复合查询接口
             *
             * */
            getTravelQuery(){
                //根据 VIN 搜索车辆
                getTravelQuery({
                    vin:this.vin
                }).then((res) => {
                    //平均车速
                    let synthesizeDriveInfo = res.results.data;
                    //被除数不能为 0
                    if(synthesizeDriveInfo.totalTime === 0){
                        synthesizeDriveInfo.speedAVG = 0;
                    }else{
                        synthesizeDriveInfo.speedAVG = synthesizeDriveInfo.totalMile / synthesizeDriveInfo.totalTime;
                    }

                    //百公里平均油耗
                    // 总油耗/总里程 * 100
                    if(synthesizeDriveInfo.totalMile === 0){
                        synthesizeDriveInfo.fuelConsumption = 0;
                    }else{
                        synthesizeDriveInfo.fuelConsumption = synthesizeDriveInfo.totalFul / synthesizeDriveInfo.totalMile * 100;
                    }

                    Object.assign(this.synthesizeDriveInfo,res.results.data);
                });
            },
            /**
             *
             *  车辆异常信息
             *
             * */
            energyAbnormity(){
                //获取车辆异常信息
                energyAbnormity({
                    vin: this.vin,
                    limit: 5000
                }).then((res) => {
                    //车辆是否有异常信息
                    this.hasAbnormity =  res.results.abnormity
                });
            },
            /**
             * 获取右侧面板接口需要的参数
             *
             * @param index   选中按钮的索引
             */
            genRightBarTimeRangeParams(){

                //得到时间范围
                let elementChecked = this.recentlyOptions.find((element)=>{
                    return element.value === this.recentlyValue;
                });
                let timeLimit = elementChecked.timeLimit;
                let nowTime = Date.now();

                //返回参数
                return {
                    start: nowTime - timeLimit,
                    end: nowTime,
                    vin: this.vin
                }

            },
            /**
             * 处理用户选中某一辆车之后的操作
             *
             * @param carData
             */
            carChecked(carData){
                console.log(carData);
                this.vin = carData.vin;
            },
            /**
             *  地图发生变化的时候的回调
             *
             * */
            initMap(){
                //初始化地图并缓存
                map = new AMap.Map('map-container', {
                    center: [116.397428, 39.90923],
                    resizeEnable: true,
                    // mapStyle:"amap://styles/blue",
                    mapStyle:"amap://styles/54546496cdede0811f122a8ef6a48ecf",
                    zoom: 5,
                    zooms:[5,18]
                });

                //先触发一下地图的数据更新

/*                map.on('moveend', (e)=>{
                    clearTimeout(mapTimer);

                    mapTimer = setTimeout(()=>{
                        this.mapChange();
                    },2000)

                });*/


            }
     },
        watch:{
            vin:function () {
                //初始化地图逻辑
                this.initMap();

                //更新右侧图表面板
                this.updateRightBar();

                //更新行驶行为分析
                this.driveTraitInfo();

                //综合行驶信息
                this.getTravelQuery();

                //车辆是否异常
                this.energyAbnormity();

                //更新地图上的点坐标
                this.updateMarkerData();


            }
        },
        components:{CarList,CarInfo,DriveLine,TopHeader}
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    @import "src/styles/mixin.scss";
    @import "src/styles/main.scss";

    .ui-logo{
        margin: 20px 40px;

    }
    dl {
        margin: 0;
        & > dd {
            margin: 0;
        }
    }



    $lightBlue:#47A4FF;
    $mangoYello:#FFAA39;

   .ui-container{
       display: flex;

       position: relative;
       width: 100%;
       height: 100%;

       // 关于模块背景色的样式
       @mixin black-style { 
           background: rgba(36,38,50,.73);
       }

       .ui-main-panel{
           display: flex;

           z-index: 2;
           /*width: 440px;*/

           padding: 15px;
           padding-top: 0;

           flex-direction:column;


           .ui-item-panel{
               position: relative;

               margin-top: 15px;

               border: 1px solid #3d3d3e;
               border-radius: 2px;
               @include black-style;

               .ui-panel-item-title{
                   display: block;
                   height: 45px;
                   padding: 10px 15px;
                   /*padding-right: 50px;*/
                   color: #fff;

                   font-size: 22px;
                   text-align: center;
               }
               .ui-panel-item-content{
                   color: #ffffff;

                   padding: 15px;

                   border-radius: 0 2px 2px 2px;
               }
           }

       }

       .ui-left-panel{
           height: calc(100% - 100px);
           width: 20%;
           position: absolute;
           left: 0;
           bottom: 0;
       }
       .ui-center-panel{
           width: 60%;
           /*height: calc(100% - 100px);*/
           position: absolute;
           left: 20%;
           top: 100px;
           padding: 0;

           .ui-drive-info-tab{
               width: 100%;

               td{
                   height: 30px;
                   line-height: 30px;
               }
           }
       }

       .ui-right-panel{
           max-height: calc(100% - 100px);
           width: 20%;
           position: absolute;
           right: 0;
           bottom: 0;
       }

       .ui-full-panel{
           max-height: 100%;
           overflow: auto;
       }
       .ui-autoheight-panel{
           flex: 1;
       }

       .map-container{
           width: 100%;
           height: 100%;
       }

       .ui-count-title{
           margin-right: 30px;
           margin-left: 50px;
       }
   }

    .ui-month-panel{

        @include clearfix;

        .ui-month-col{
            width: 33.333%;
            display: inline-block;
            float: left;

            text-align: center;
        }


    }

    .ui-btn-container{
        text-align: right;
        margin-top: 18px;
    }

    .ui-def-btn{
        background: none;
        border-radius: 0;
        border-color: #444;
        color: #fff;
        font-size: 16px;
        &.active{
            /*background: linear-gradient(left,red,blue);*/
            background: -webkit-linear-gradient(left, #1b5890 , #475a90); /* Safari 5.1 - 6.0 */
        }
    }

    .ui-drive-data-tab{
        td{
            height: 35px;
            line-height: 35px;
        }
    }

</style>

<style rel="stylesheet/scss" lang="scss">
    .min-font-style{
        .el-progress__text{
            font-size: 13px!important;
            color: #fff;
        }
        .el-progress-bar__outer{
            background-color: #303755;
        }
    }

    .black-progress-circle{
        .el-progress-circle__track{
            /*stroke: #3d3e44;*/
            stroke: rgba(139,139,139,0.3);
        }

        .el-progress__text{
            font-size: 20px!important;
            color: #fff;
        }
    }


    .amap-marker-label {
        background: rgba(37,41,61,0.68);
        border: 1px solid rgba(61,61,62,0.68);
        border-radius: 4px;
        font-size: 14px;
        color: #fff;
        width: 250px;
        min-height: 70px;
        text-align: center;

        padding: 15px;
    }

    .ui-marker-window{
        &>div{
            margin: 10px 0;
            text-align: left;
        }

        .ui-marker-title{
            font-size: 18px;
            text-align: center;
        }

    }



    .ui-datav-select{
        display: inline-block;
        float: right;
        width: 120px;

        .el-input__inner{
            background: none;
            border-color: #444;
            color: #fff;
            border-radius: 0;
        }
    }

    .el-select-dropdown{
        border: 1px solid #444;
        border-radius: 0;
        background-color: #1a1c24;
        color: #fff;

        .el-select-dropdown__item{
            &.hover,&:hover{
                background-color: #373738;
            }
        }
    }
    .el-popper[x-placement^=bottom] .popper__arrow::after{
        top: 0px;
        margin-left: -6px;
        border-bottom-color: #444;
    }
</style>