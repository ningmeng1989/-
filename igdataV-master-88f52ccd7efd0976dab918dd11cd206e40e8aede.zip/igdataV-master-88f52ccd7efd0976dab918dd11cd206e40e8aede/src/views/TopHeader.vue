<!-- 顶部菜单 -->
<template>
    <header class="ui-container-head">
        <div class="ui-subtitle">
            {{headTitle || "数据可视化平台"}}
        </div>
        <div class="ui-head-right">
                <span class="ui-time">
                {{timeDisplay}}
                </span>
            <el-button class="ui-change-btn" v-for="btn in btns">
                <router-link :to="btn.to">
                    <i class="el-icon-back"></i>
                    {{btn.value}}
                </router-link>
            </el-button>
        </div>
    </header>
</template>

<script>
    import dateUtils from '@/utils/dateUtils';

    export default {
        name: "TopHeader",
        data(){
            return {
                timeDisplay: ""
            }
        },
        methods:{
            /**
             *  初始化右上角的日期时间
             *
             * */
            initTimeDisplay(){
                this.timeDisplay = new Date().format();

                setInterval(()=>{
                    this.timeDisplay = new Date().format("yyyy年MM月dd日 hh:mm:ss");
                },1000);
            }
        },
        mounted(){
            this.initTimeDisplay();
        },
        props:["btns","headTitle"]
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    .ui-container-head{
        position: absolute;
        top: 0;
        left: 0;

        z-index: 3;

        width: 100%;
        height: 80px;

        background:url("/static/img/head_back2.png") no-repeat;

        .ui-subtitle{
            display: inline-block;
            margin: 28px 0 0 250px;

            font-size: 30px;
            color: #fff;
        }

        //@include black-style;

        .ui-head-right{
            height: 80px;
            line-height: 80px;
            vertical-align: middle;
            margin-right: 30px;

            float: right;
        }

        .ui-time{
            font-family: PingFangSC-Regular;
            font-size: 24px;
            color: #FFFFFF;
            letter-spacing: 0;
            margin: 0 35px;
        }
        .ui-change-btn{
            opacity: 0.73;
            background: #242632;
            border: 1px solid #3D3D3E;
            border-radius: 4px;

            font-size: 20px;
            color: #0070FF;
        }

    }
</style>
