<template>
  <div class="login-container">

    <div class="ui-page-logo">
      <img src="/static/img/login_logo.png" class="ui-login-logo"/>
    </div>

    <el-form :model="loginForm" :rules="loginRules" ref="loginForm" label-position="left" label-width="0px" class="card-box login-form animated fadeInDown">
      <div>
        <img src="/static/img/login_logo.png" class="ui-login-logo"/>
      </div>
      <el-form-item prop="username">
        <el-input style="width:100%;" name="username" type="text" v-model="loginForm.username" placeholder="请输入账号" prefix-icon="ui-pngicon ui-pngicon-user" autocomplete="off"/>
      </el-form-item>
      <el-form-item prop="password" style="margin-top: 44px;">
        <el-input style="width:100%;" name="password" type="password" @keyup.enter.native="handleLogin" v-model="loginForm.password" placeholder="请输入密码" prefix-icon="ui-pngicon ui-pngicon-password" autocomplete="off"></el-input>
      </el-form-item>
      <div>
        <el-button type="primary" class="ui-login-btn" :loading="loading" @click.native.prevent="handleLogin" >
          登陆
        </el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
import { isvalidUsername } from "@/utils/validate";
export default {
  name: "login",
  data() {
    const validateUsername = (rule, value, callback) => {
      if (!isvalidUsername(value)) {
        callback(new Error("请输入正确的用户名"));
      } else {
        callback();
      }
    };
    const validatePass = (rule, value, callback) => {
      if (value.length < 6) {
        callback(new Error("密码不能小于6位"));
      } else {
        callback();
      }
    };
    return {
      loginForm: {
        username: "",
        password: ""
      },
      loginRules: {
        // username: [{ required: true, trigger: 'blur', validator: validateUsername }],
        password: [{ required: true, trigger: "blur", validator: validatePass }]
      },
      loading: false,
      emptyStr: ""
    };
  },
  methods: {
    handleLogin() {
        this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true;
          this.$store
            .dispatch("Login", this.loginForm)
            .then(() => {
              this.loading = false;
              this.$router.push({ path: "/" });
            })
            .catch(() => {
              this.loading = false;
            });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss">
@import "src/styles/mixin.scss";
@import "src/styles/animate.scss";
$dark_gray: #333333;

.login-container {
  @include relative;
  height: 100vh;

  .ui-page-logo{
    position: absolute;
    top: 5%;
    left: 10%;
    font-size: 40px;
    color: #fff;
  }

/*  background: url(../../../static/img/loginbg.jpg) no-repeat;
  background-size: 100% 100%;*/
  background:url("/static/img/login_back.png") no-repeat;
  background-size: 100% 100%;
  background-color: black;
  input:-webkit-autofill {
    box-shadow: 0 0 0px 1000px transparent inset !important;
    -webkit-text-fill-color: $dark_gray !important;
  }

  input {
    background: transparent;
    border: 0px;
    -webkit-appearance: none;
    border-radius: 0px;
    padding: 12px 5px 12px 15px;
    color: $dark_gray;
    height: 47px;
  }
  .el-form-item,.el-form-item__content{
    background: transparent!important;
  }
  .el-form-item{
    border: 1px solid #21222a;
    border-radius: 2px;
  }
  .el-input {
    display: inline-block;
    /*height: 36px;*/
    width: 85%;
  }
  .tips {
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;
  }
  .title {
    font-size: 20px;
    font-weight: 400;
    color: #fff;
    margin: 0px auto 40px auto;
    text-align: center;
    font-weight: bold;
    letter-spacing: 2px;
  }
  .login-form {
    position: absolute;
    left: 0px;
    right: 0px;
    top: 0px;
    bottom: 0px;
    /* vertical-align: middle; */
    height: 530px;
    width: 415px;
    padding: 35px 35px 15px 35px;
    margin:auto;
    margin-right: 10%;
    background: #14151b;
    border-radius: 8px;
    /*box-shadow: 0 0 8px 0 rgba(32, 60, 102, 0.3);*/
  }

  .el-input--prefix .el-input__inner {
    padding-left: 45px;
  }
  .el-form-item {
    background: #fff;
    border-radius: 2px;
    color: $dark_gray;
  }
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 7px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
  }
  .thirdparty-button {
    position: absolute;
    right: 35px;
    bottom: 28px;
  }

  .ui-login-btn{
    width: 100%;
    margin-top: 46px;
    padding: 19px;
    font-size: 16px;
    background: linear-gradient(to right, #1c5eb9 , #19356d); /* 标准的语法（必须放在最后） */
    border: 0;
  }
  .el-form-item__error{
    padding-top: 12px;
  }

  .el-input--medium .el-input__inner {
    height: 56px;
    line-height: 56px;
    color: #5e77aa;
    font-size: 16px;
  }

  .el-input__icon{
    color: #5e77aa;
  }

  input::-webkit-input-placeholder, textarea::-webkit-input-placeholder {
    /* WebKit browsers */
    color: #5e77aa;
  }

  .ui-login-logo{
    display: block;
    margin: auto;
    margin-bottom: 40px;
  }

  /* input:-webkit-autofill, textarea:-webkit-autofill, select:-webkit-autofill {
     background-color: red !important;
     background-image: none !important;
     color: rgb(0, 0, 0) !important;
   }*/
}

.ui-pngicon {
  display: block;

  position: absolute;
  top: 0;
  bottom: 0;

  width: 28px;
  height: 28px;
  margin: auto;

  background-repeat: no-repeat;

}

.ui-pngicon-user {
  background: url("/static/img/home/user.png") no-repeat;
}

.ui-pngicon-password {
  background: url("/static/img/home/password.png") no-repeat;
}
</style>
