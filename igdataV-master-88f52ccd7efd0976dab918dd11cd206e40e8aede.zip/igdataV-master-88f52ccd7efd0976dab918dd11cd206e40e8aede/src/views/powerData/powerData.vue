<template>
    <div class="ui-container">
        <!-- 顶部菜单 -->
        <TopHeader  headTitle="动力数据分析" :btns="[{value:'返回',to:'/'}]"></TopHeader>
        <!-- /顶部菜单 -->

        <!-- 左侧菜单面板 -->
        <section class="ui-left-panel ui-main-panel">

            <div class="ui-item-panel ui-autoheight-panel">
                <header class="ui-panel-item-title">
                    选择车型
                </header>
                <div class="ui-panel-item-content">
                    <el-row>
                        <el-col v-for="(carType,index) in carTypeList" :key="carType.code" :span="12">
                            <div class="ui-cartype-container" :class="{active:carType.checked}" @click="checkCarType(index)">
                                <div class="ui-car-img">
                                    <img :src="carType.imgURL" alt="">
                                </div>
                                <div class="ui-car-name">{{carType.name}}</div>
                            </div>
                        </el-col>
                    </el-row>
                    <!--分页器-->
<!--                    <div class="ui-cartype-footer">
                        <el-pagination
                                layout="prev, pager, next"
                                :total="50">
                        </el-pagination>
                    </div>-->
                </div>
            </div>
            <!--<div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    基础数据
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <div class="ui-carlist-container">
                        <el-row>
                            <el-col :span="12">
                                <img :src="carTypeChecked.imgURL" alt="">
                            </el-col>
                            <el-col :span="12" style="text-align: center;">
                                <div class="ui-car-tag">{{carTypeChecked.name}}</div>
                            </el-col>
                        </el-row>
                        <table class="ui-carlist-tab">
                            <tbody>
                            <tr>
                                <td style="color: #47A4FF;">电池品牌：{{batteryData.band}}</td>
                            </tr>
                            <tr>
                                <td style="color: #FFAA39;">
                                    电池类型：
                                    <span v-if="batteryData.type==1">锂离子电池</span>
                                    <span v-else-if="batteryData.type==2">镍氢电池</span>
                                    <span v-else-if="batteryData.type==3">燃料电池</span>
                                    <span v-else-if="batteryData.type==4">铅酸电池</span>
                                </td>
                            </tr>
                            <tr>
                                <td >
                                    电池包额定电压：{{batteryData.packVoltage}}V
                                </td>
                            </tr>
                            <tr>
                                <td>电池模组额定容量：{{batteryData.moduleVoltage}}V</td>
                            </tr>
                            <tr>
                                <td>电池模组额定电压：{{batteryData.moduleVoltage}}V</td>
                            </tr>
                            <tr>
                                <td>电池包厂家 ：{{batteryData.packManufacturer}}</td>
                            </tr>
                            <tr>
                                <td >电芯厂家 ：{{batteryData.coreManufacturer}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>-->

        </section>
        <!-- /左侧菜单面板 -->

        <!--中间栏面板 -->
        <section class="ui-center-panel ui-main-panel">
            <div class="ui-item-panel">
                <header class="ui-panel-item-title">
                    实时数据 <span style="margin-left: 85px;">当前正在充电车  <span style="color: #47A4FF;">{{chargingNumNow}}</span> 辆</span>
                </header>
                <div class="ui-panel-item-content min-font-style">
                    <TimeLine title="24小时充电车辆数" mainColor="#5e3536" @updateCount="updateCarCount" :lineColor="['#5D2880','#3193D7']" ></TimeLine>
                    <div style="text-align: center;padding-top: 15px;">时刻（近24小时）</div>
                </div>
            </div>
            <div class="ui-item-panel ui-autoheight-panel">
                <header class="ui-panel-item-title">
                    <span>综合分析</span>
                    <div class="ui-carexception-btn-wrap">
                        <el-button type="primary" round @click="toggleCarExceptionList()" style="background: linear-gradient(-90deg, #366EB6 0%, #414CA8 100%);border: 0;">电耗异常车辆</el-button>
                    </div>
                    <div class="ui-btn-container">
                        <el-button v-for="(btnObj,index) in btns" class="ui-def-btn" :key="btnObj.timeLimit" :class="{active:index == btnIndexChecked}" @click="btnChange(index)">{{btnObj.name}}</el-button>
                    </div>
                </header>
                <div class="ui-panel-item-content" style="margin-top: 10px;">
                    <!--电耗异常车辆列表-->
                    <div class="ui-charge-exception" v-show="showCarExceptionList">
                        <CarChargeExceptionList :carList="abnormityCarsData" @hideList="toggleCarExceptionList()"></CarChargeExceptionList>
                    </div>
                    <!--/电耗异常车辆列表-->
                    <el-row>
                        <el-col :span="8">
                            <div class="ui-left-title-chart">
                                <div class="ui-left-title">车辆数</div>
                                <div class="ui-right-content">
                                    <FullLine title="充电起始时刻的剩余电量分布" mainColor="#4CB6FF" :lineColor="['#E55F94','#E47F5F']" :driveData="startSocLineData"></FullLine>
                                </div>
                            </div>
                            <div class="ui-driveline-scription">剩余电量百分比（%）</div>
                        </el-col>
                        <el-col :span="8">
                            <div class="ui-left-title-chart">
                                <div class="ui-left-title">车辆数</div>
                                <div class="ui-right-content">
                                    <Bar title="充电起始时刻分布" mainColor="#FA594D" :lineColor="['#13AD6C','#62D46C']" :driveData="startChargingTimeLineData"></Bar>
                                </div>
                            </div>

                            <div class="ui-driveline-scription">时间段（24小时）</div>
                        </el-col>
                        <el-col :span="8">
                            <div class="ui-left-title-chart">
                                <div class="ui-left-title">车辆数</div>
                                <div class="ui-right-content">
                                    <Bar title="充电持续时间分布" mainColor="#FF8805" :lineColor="['#E29D14','#EDCB49']" :driveData="chargingTime4HourLineData"></Bar>
                                </div>
                            </div>

                            <div class="ui-driveline-scription">时间段（24小时）</div>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <div class="ui-left-title-chart">
                                <div class="ui-left-title">车辆数</div>
                                <div class="ui-right-content">
                                    <FullLine title="充电结束时刻的剩余电量分布" mainColor="#4CB6FF" :lineColor="['#31C496','#3EAEDF']" :driveData="endSocLineData"></FullLine>
                                </div>
                            </div>
                            <div class="ui-driveline-scription">剩余电量百分比（%）</div>
                        </el-col>
                        <el-col :span="8">
                            <div class="ui-left-title-chart">
                                <div class="ui-left-title">车辆数</div>
                                <div class="ui-right-content">
                                    <Bar title="充电结束时刻分布" mainColor="#FF8805" :lineColor="['#13AD6C','#62D46C']" :driveData="endChargingTimeLineData"></Bar>
                                </div>
                            </div>
                            <div class="ui-driveline-scription">时间段（24小时）</div>
                        </el-col>
                        <el-col :span="8">
                            <div class="ui-left-title-chart">
                                <div class="ui-left-title">车辆数</div>
                                <div class="ui-right-content">
                                    <Bar title="充电频率分布" mainColor="#4CB6FF" :lineColor="['#E29D14','#EDCB49']" :driveData="chargingByDayData"></Bar>
                                </div>
                            </div>
                            <div class="ui-driveline-scription">时间段（24小时）</div>
                        </el-col>
                    </el-row>
                </div>
            </div>
        </section>
        <!-- /中间栏面板 -->

        <!-- 右侧菜单面板 -->
        <!--<section class="ui-right-panel ui-main-panel">
            <div class="ui-item-panel ui-full-panel">
                <header class="ui-panel-item-title">
                    日常行驶数据
                </header>
                <div class="ui-panel-item-content">
                    <div class="ui-month-panel min-font-style">
                        <DriveLine title="在线时长" mainColor="#3FB04C" style="margin-top: 0;" :lineColor="['#7AFE8A','#0F8E6B']"></DriveLine>
                        <DriveLine title="报警数" mainColor="#FA594D" :lineColor="['#FF99BA','#FA2C60 ']"></DriveLine>
                        <DriveLine title="能耗" mainColor="#FF8805" :lineColor="['#FF9500','#FF9500']"></DriveLine>
                        <DriveLine title="行驶里程" mainColor="#4CB6FF" :lineColor="['#5AB2FF','#5442FF']"></DriveLine>
                    </div>
                </div>
            </div>
        </section>-->
        <!-- /右侧菜单面板 -->


        <!-- 背景地图 -->
        <!--<div class="map-container" id="map-container"></div>-->
        <!-- /背景地图 -->
    </div>
</template>

<script>
    import CarList from "@/components/carData/CarList.vue";
    import CarChargeExceptionList from "@/components/carData/CarChargeExceptionList.vue";
    import TopHeader from "@/views/TopHeader.vue"
    import TimeLine from "@/components/dlCharts/TimeLine.vue";
    import FullLine from "@/components/dlCharts/FullLine.vue";
    import Bar from "@/components/dlCharts/Bar.vue";
    import carTypeImgMap from '@/map/carTypeImgMap';
    import {
        getBattery,
        chargingByDay,
        startChargingTime,
        endChargingTime,
        chargingTime4Hour,
        endSoc,
        startSoc,
        chargingCount4time,
        abnormityCars,
        getCarTypes
    } from "@/api/powerData";


    export default {
        name: "power-data",
        data() {
            return {
                timeDisplay: "",
                //时间段选择按钮
                btns: [
                    {
                        name:"最近一周",
                        timeLimit: 86400000 * 7
                    },
                    {
                        name:"最近一月",
                        timeLimit: 86400000 * 30
                    },
                    {
                        name:"最近三月",
                        timeLimit: 86400000 * 90
                    },
                    {
                        name:"最近半年",
                        timeLimit: 86400000 * 182.5
                    },
                    {
                        name:"最近一年",
                        timeLimit: 86400000 * 365
                    }
                ],
                //车型列表
                carTypeList:[],
                //选中时间段按钮索引
                btnIndexChecked:1,
                //车型code
                code:"CT00005",
                //充电起始时刻的剩余电量分布数据
                startSocLineData:{},
                //充电结束时刻的剩余电量分布数据
                endSocLineData:{},
                //24小时充电车辆数
                chargingCount4timeLineData:{},
                //充电起始时刻分布
                startChargingTimeLineData:{},
                //充电结束时刻分布
                endChargingTimeLineData:{},
                //充电持续时间分布
                chargingTime4HourLineData:{},
                //指定时间段内每日充电频次
                chargingByDayData:{},
                //电池基础数据
                batteryData:{},
                //指定车型故障车辆列表
                abnormityCarsData:[],
                //当前选中的车型
                carTypeChecked:{},
                //当前正在充电车辆数量
                chargingNumNow:0,
                map: "",
                vin: "",  //选中的车辆的vin
                //机构车辆数TOP 6
                carTop6: [],
                //机构在线时长TOP 6
                timeTop6: [],
                alertTop6: [],
                //当前的行政区域聚合
                distCluster: "",
                //车辆总数
                carCount: 0,
                //当前在线总数
                onlineCount: 0,
                //隐藏/显示 电耗异常车辆列表
                showCarExceptionList: false,
                mapTimer: ""
            }
        },
        mounted(){
            this.getCarTypes();
        },
        methods: {
            /**
             * 更新当前选中车辆数
             *
             * @param carCount   当前充电车辆数
             */
            updateCarCount(carCount){
                //更新当前选中车辆数
                this.chargingNumNow = carCount;
            },

            /**
             * 开关电耗异常车辆列表
             *
             */
            toggleCarExceptionList(){
                //更新当前选中车辆数
                this.showCarExceptionList = !this.showCarExceptionList;
            },/**
             * 按钮选中的切换方法
             *
             * @param index   选中按钮的索引
             */
            btnChange(index){
                //当前点击按钮设为选中
                this.btnIndexChecked = index;

                //更新页面主要数据
                this.updateCommon();
            },
            /**
             * 获取搜索基本参数，包含选中车型，起止时间等等
             *
             */
            getBaseParams(){
                //生成时间范围
                let searchTimeRange = this.genTimeRangeParams(this.btnIndexChecked);

                //生成基本的搜索参数
                let baseParams = Object.assign(searchTimeRange,{
                    "vehicleType":this.carTypeChecked.code
                });
                return baseParams;

            },
            /**
             * 按钮选中的切换方法
             *
             * @param index   选中按钮的索引
             */
            genTimeRangeParams(index) {

                //得到时间范围
                let timeLimit = this.btns[index].timeLimit;
                let nowTime = Date.now();

                //起止时间数据
                return {
                    start: nowTime - timeLimit,
                    end: nowTime
                }

            },
            /**
             *
             *  获取指定时间段内每日充电频次接口
             *
             * */
            chargingByDay(){
                //获取基本的搜索参数
                let params = this.getBaseParams();
                //获取开始充电时刻分布数据接口
                chargingByDay(params).then((res) => {
                    this.chargingByDayData = res.results;
                });
            },
            /**
             *
             *  开始充电时刻分布数据接口
             *
             * */
            startChargingTime(){
                //获取基本的搜索参数
                let params = this.getBaseParams();
                //获取开始充电时刻分布数据接口
                startChargingTime(params).then((res) => {
                    this.startChargingTimeLineData = res.results;
                });
            },
            /**
             *
             *  结束充电时刻分布数据接口
             *
             * */
            endChargingTime(){
                //获取基本的搜索参数
                let params = this.getBaseParams();
                //获取开始充电时刻分布数据接口
                endChargingTime(params).then((res) => {
                    this.endChargingTimeLineData = res.results;
                });
            },
            /**
             *
             *  充电持续时间分布数据接口
             *
             * */
            chargingTime4Hour(){
                //获取基本的搜索参数
                let params = this.getBaseParams();
                //获取开始充电时刻分布数据接口
                chargingTime4Hour(params).then((res) => {
                    this.chargingTime4HourLineData = res.results;
                });
            },
            /**
             *
             *  开始充电时刻分布数据接口
             *
             * */
            startSoc(){
                //获取基本的搜索参数
                let params = this.getBaseParams();
                //获取开始充电时刻分布数据接口
                startSoc(params).then((res) => {
                    this.startSocLineData = res.results;
                    // this.$set(this.startSocLineData,res.results);
                    console.log(this.startSocLineData);
                });
            },
            /**
             *
             *  结束充电时刻分布数据接口
             *
             * */
            endSoc(){
                //获取基本的搜索参数
                let params = this.getBaseParams();
                //获取开始充电时刻分布数据接口
                endSoc(params).then((res) => {
                    this.endSocLineData = res.results;
                });
            },
            /**
             *
             *  结束充电时刻分布数据接口
             *
             * */
            chargingCount4time(){
                //获取基本的搜索参数
                let params = {
                    "vehicleType":"CT00080"
                };

                //获取开始充电时刻分布数据接口
                chargingCount4time(params).then((res) => {
                    console.log(res);

                    //格式化一下数据，为 [1,2,3,88,5]
                    let data = res.results.map((element)=>{
                        return element.value;
                    });

                    console.log({
                        category:["0-10","10-20","20-30","30-40","40-50","50-60","60-70","70-80","80-90","11:00"],
                        data: data
                    });

                    // {"code":0,"data":[24,16,7,8,10,8,5,4,5,4],"category":["0-10","10-20","20-30","30-40","40-50","50-60","60-70","70-80","80-90","90-100"]}
                    //设置当前充电车辆
                    this.chargingNumNow = data[data.length - 1];

                    //设置图表
                    this.chargingCount4timeLineData = {
                        category:["12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","00:00","01:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00"],
                        data: data
                    };
                });
            },
            /**
             *
             *  获取车型列表
             *
             * */
            getCarTypes(){
                //获取车型列表
                getCarTypes().then((res) => {

                    //TODO 测试数据
                    res.results = [
                        {"code": "CT00001", "name": "金刚"},
                        {"code": "CT00010", "name": "远景X3"},
                        {"code": "CT00014", "name": "全球鹰康迪K17A"},
                        {"code": "CT00050", "name": "轻卡E200"},
                        {"code": "CT00051", "name": "客车E12"},
                        {"code": "CT00052", "name": "客车E10"},
                        {"code": "CT00080", "name": "KC-2HB"},
                        {"code": "CT00005", "name": "帝豪EV"},
                        {"code": "CT00003", "name": "帝豪GL"},
                        {"code": "CT00082", "name": "SX11P"},
                        {"code": "CT00081", "name": "VF11P"}
                    ];

                    //TODO:TOP 6 根据车型匹配对应的车型图片
                    let carTypeList = res.results.map((element, index) => {

                        //默认选中第一个
                        if(index === 0){
                            element.checked = true;
                        }else{
                            element.checked = false;
                        }

                        //加上 imgURL
                        return Object.assign(element, {
                            "imgURL": carTypeImgMap[element.code]
                        })

                    });

                    this.carTypeList  = carTypeList;

                    //设置基本的搜索参数
                    this.carTypeChecked = Object.assign(this.carTypeChecked,carTypeList[0]);

                    //TODO 测试数据  用完记得删除
                    let demoData = Object.assign({}, carTypeList[0]);
                    demoData.code = "CT00080";
                    this.carTypeChecked = demoData;

                    //更新页面数据
                    this.updateCommon();

                });
            },
            /**
             *
             *  获取车型电池基本数据
             *
             * */
            getBattery(){
                //车型基本数据
                let carTypeBaseInfo = this.carTypeChecked;
                //获取车型电池基本数据
                getBattery({
                    code:this.code
                }).then((res) => {
                    this.batteryData = Object.assign(res.results, carTypeBaseInfo);
                });
            },
            /**
             *
             *  获取指定车型故障车辆列表
             *
             * */
            abnormityCars(){
                //获取车型电池基本数据
                abnormityCars({
                    vehicleType:this.carTypeChecked.code
                }).then((res) => {
                    //TODO 测试数据
                    res.results = [{
                        "plate": "浙C88888",
                        "vin": "123456",
                        "type":"博瑞GE MHEV"
                    }];


                    this.abnormityCarsData = res.results;
                });
            },
            /**
             *  根据索引选中某一个车型
             *
             * */
            checkCarType(index){
                //老选中元素的索引
                let oldIndex = this.carTypeList.findIndex((element) => {
                    return element.checked == true;
                });
                this.carTypeList[oldIndex].checked = false;
                this.carTypeList[index].checked = true;

                //TODO 测试数据  用完记得删除
                let demoData = Object.assign({}, this.carTypeList[index]);
                demoData.code = "CT00080";

                this.carTypeChecked = demoData;

                //更新页面数据
                this.updateCommon();
            },
            /**
             *  更新页面的主要数据
             *
             * */
            updateCommon(){
                //设置充电基本数据
                this.getBattery();

                //设置开始充电时刻分布数据接口
                this.startChargingTime();

                //设置结束充电时刻分布数据接口
                this.endChargingTime();

                //充电持续时间分布数据接口
                this.chargingTime4Hour();

                //startSoc
                this.startSoc();

                //endSoc
                this.endSoc();

                //chargingCount4time
                this.chargingCount4time();

                //chargingByDay
                this.chargingByDay();

                //abnormityCars
                this.abnormityCars();
            }
     },
       /* watch:{
            carTypeChecked: {
                immediate:true,
                handler:function () {
                    this.updateCommon();
                }
            },
            btnIndexChecked: function () {
                this.updateCommon();
            }
        },*/
        components:{CarList,TimeLine,TopHeader,Bar,FullLine,CarChargeExceptionList}
    }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
    @import "src/styles/mixin.scss";


    .ui-logo{
        margin: 20px 40px;

    }
    dl {
        margin: 0;
        & > dd {
            margin: 0;
        }
    }



    $lightBlue:#47A4FF;
    $mangoYello:#FFAA39;

   .ui-container{
       display: flex;

       position: relative;
       width: 100%;
       height: 100%;
       min-height: 1150px;

       background: #000000;

       // 关于模块背景色的样式
       @mixin black-style { 
           background: rgba(36,38,50,.73);
       }

       .ui-container-head{
           position: absolute;
           top: 0;
           left: 0;

           z-index: 3;
           
           width: 100%;
           height: 80px;

           background:url("/static/img/head_back.png") no-repeat;

           //@include black-style;

           .ui-head-right{
               height: 80px;
               line-height: 80px;
               vertical-align: middle;
               margin-right: 30px;

               float: right;
           }

           .ui-time{
               font-family: PingFangSC-Regular;
               font-size: 24px;
               color: #FFFFFF;
               letter-spacing: 0;
               margin: 0 35px;
           }
           .ui-change-btn{
               opacity: 0.73;
               background: #242632;
               border: 1px solid #3D3D3E;
               border-radius: 4px;

               font-size: 20px;
               color: #0070FF;
           }
           
       }

       .ui-main-panel{
           display: flex;

           z-index: 2;
           /*width: 440px;*/

           padding: 15px;
           padding-top: 0;

           flex-direction:column-reverse;


           .ui-item-panel{
               position: relative;

               margin-top: 15px;

               border: 1px solid #3d3d3e;
               border-radius: 2px;
               @include black-style;

               .ui-panel-item-title{
                   display: block;
                   height: 45px;
                   padding: 10px 15px;
                   padding-right: 0;
                   color: #fff;

                   font-size: 22px;
               }
               .ui-panel-item-content{
                   position: relative;

                   color: #ffffff;

                   padding: 15px;

                   border-radius: 0 2px 2px 2px;
               }
           }

       }

       .ui-left-panel{
           height: calc(100% - 100px);
           width: 20%;
           position: absolute;
           left: 0;
           bottom: 0;
       }
       .ui-center-panel{
           width: 80%;
           height: calc(100% - 100px);
           position: absolute;
           left: 20%;
           bottom: 0;
           padding: 0 15px 15px 0;

           .ui-drive-info-tab{
               width: 100%;

               td{
                   height: 30px;
                   line-height: 30px;
               }
           }
       }

/*       .ui-right-panel{
           max-height: calc(100% - 100px);
           width: 20%;
           position: absolute;
           right: 0;
           bottom: 0;
       }*/

       .ui-full-panel{
           max-height: 100%;
           overflow: auto;
       }
       .ui-autoheight-panel{
           flex: 1;
       }

       .map-container{
           width: 100%;
           height: 100%;
       }

       .ui-count-title{
           margin-right: 30px;
           margin-left: 50px;
       }
   }

    .ui-month-panel{

        @include clearfix;

        .ui-month-col{
            width: 33.333%;
            display: inline-block;
            float: left;

            text-align: center;
        }


    }

    .ui-btn-container{
        float: right;
        display: inline-block;
        width: 50%;
        margin-right: 2px;
        text-align: right;
    }

    .ui-def-btn{
        background: none;
        border-radius: 0;
        border-color: #444;
        color: #fff;
        font-size: 16px;
        &.active{
            /*background: linear-gradient(left,red,blue);*/
            background: -webkit-linear-gradient(left, #1b5890 , #475a90); /* Safari 5.1 - 6.0 */
        }
    }

    .ui-driveline-scription{
        padding: 5px 0;
        text-align: center;
        color: #BAB3B3;
        font-size: 14px;
    }

    .ui-carlist-tab{
        width: 100%;
        text-align: center;

        &>thead td{
            height: 30px;
            line-height: 30px;
            font-size: 18px;

            &:nth-child(1){
                color: #0C7FFF;
            }
            &:nth-child(2){
                color: #FFAA39;
            }
            &:nth-child(3){
                color: #36A666;
            }
        }

        &>tbody td{
            height: 30px;
            line-height: 30px;
            font-size: 16px;
            color: #FFFFFF;
            text-align: left;
        }
    }




    .ui-car-tag{
        display: inline-block;
        padding: 5px 15px;
        background: -webkit-linear-gradient(left, #366EB6, #414CA8);
        border-radius: 100px;
        margin-top: 20px;
    }
    .ui-cartype-container{
        height: 98px;

        cursor: pointer;

        &.active{
            background: url(/static/img/powerData/car_checked.png) no-repeat 100% 100%;
            background-position: center;
            background-size: contain;
        }
    }
    .ui-car-img{
        min-height: 66px;
    }
    .ui-car-name{
        text-align: center;
    }


    .ui-left-title-chart{
        display: flex;
        .ui-left-title{
            writing-mode:vertical-rl;
            padding: 5px 0;
            text-align: center;
            color: #BAB3B3;
            font-size: 14px;
            letter-spacing: 5px;
            position: relative;
            right: -15px;
        }
        .ui-right-content{
            flex: 1;

        }
    }

    .ui-carexception-btn-wrap{
        float: right;
        display: inline-block;

        width: 25%;
        text-align: center;

    }

    .ui-charge-exception{
        position: absolute;
        right: -1px;
        top: 1px;

        z-index: 2;

        width: 25%;
        height: 100%;
        padding: 15px;

        background-color: rgba(36,38,50,0.94);
        border: 1px solid #3D3D3E;

    }



</style>

<style rel="stylesheet/scss" lang="scss">
    .ui-cartype-footer{
        & *{
            background: none!important;
            color: #414CA8;
        }

        .el-pagination{
            text-align: center;
        }
    }
</style>