基于vue和element-ui组件库的基础上开发。



## 环境依赖

  * node >= 4.0.0
  * npm >= 3.0.0
  * webpack >= 2.0.0

## 如何使用

1. npm install          (重新安装所有依赖)
2. npm start  || npm dev          (开启本地开发)
3. Npm build            (构建发布包)

## 代码结构

```js
├── build
├── config
├── dist                            // 发布包
│   └── static
│       ├── css
│       ├── fonts
│       ├── img
│       └── js
├── src								// 开发目录
│   ├── api
│   ├── assets
│   │   ├── 404_images
│   │   └── img
│   ├── components					// 业务组件
│   │   ├── ControlPage
│   │   ├── Echarts
│   │   ├── Hamburger
│   │   ├── Icon-svg
│   │   ├── ScrollPane
│   │   ├── VerificationBox
│   │   ├── carCenter
│   │   ├── maps
│   │   └── oss
│   ├── icons
│   │   └── svg
│   ├── router 						// 路由
│   ├── store						//vuex路径
│   │   └── modules
│   ├── styles
│   ├── utils
│   └── views						//业务代码
│       ├── carsCenter
│       ├── control
│       ├── dashboard
│       ├── dataAnalysis
│       ├── dataCenter
│       ├── device
│       ├── layout
│       ├── login
│       ├── management
│       ├── page
│       ├── risk
│       ├── table
│       └── trajectory
└── static							//静态图片地址不会被webpack打包
    └── img
```