<template>
  <up-load></up-load>
</template>

<style lang="scss" scoped>

</style>

<script>
import UpLoad from "@/components/oss/upload.vue"
export default{
  components:{UpLoad},
}
</script>