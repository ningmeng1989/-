<template>
    <div>
        这是权限管理页面
    </div>
</template>

<script>
    export default {
        name: "privilege-manage"
    }
</script>

<style scoped>

</style>