<template>
    <div>
        <map-detail></map-detail>
    </div>
</template>

<script>
    import MapDetail from  '@/components/carCenter/mapDetail.vue';
    export default {
        name: "control-car",
        components:{MapDetail},
    }
</script>

<style scoped>
</style>