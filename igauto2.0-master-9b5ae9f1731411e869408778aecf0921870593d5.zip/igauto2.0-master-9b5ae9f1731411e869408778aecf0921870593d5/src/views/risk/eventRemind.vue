<template>
    <div>这是事件提醒页面</div>
</template>

<script>
    export default {
        name: "event-remind"
    }
</script>

<style scoped>

</style>